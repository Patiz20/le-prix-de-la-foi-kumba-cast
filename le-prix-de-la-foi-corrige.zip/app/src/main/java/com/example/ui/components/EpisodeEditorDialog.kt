package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.EpisodeEntity
import com.example.data.model.SceneModel
import com.example.ui.theme.GoldPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EpisodeEditorDialog(
    episode: EpisodeEntity,
    onDismiss: () -> Unit,
    onSave: (EpisodeEntity) -> Unit
) {
    var titleFr by remember { mutableStateOf(episode.titleFr) }
    var titleLn by remember { mutableStateOf(episode.titleLn) }
    var synopsis by remember { mutableStateOf(episode.synopsis) }
    var durationSec by remember { mutableIntStateOf(episode.durationSeconds.coerceIn(45, 90)) }
    var primaryTheme by remember { mutableStateOf(episode.primaryTheme) }
    var bibleVerseRef by remember { mutableStateOf(episode.bibleVerseRef) }
    var bibleVerseFr by remember { mutableStateOf(episode.bibleVerseFr) }
    var bibleVerseLn by remember { mutableStateOf(episode.bibleVerseLn) }
    var hookFr by remember { mutableStateOf(episode.hookFr) }
    var hookLn by remember { mutableStateOf(episode.hookLn) }
    var visualPrompt by remember { mutableStateOf(episode.visualPrompt) }
    var montageGuide by remember { mutableStateOf(episode.montageGuide) }

    val initialScenes = remember {
        val parsed = SceneModel.parseList(episode.scenesJson)
        if (parsed.isEmpty()) {
            listOf(
                SceneModel(1, 0, 15, "Samuel", "Gros plan", "Zoom avant lent", "Dilemme moral", "Je ne peux pas faire ça...", "Nakoki kosala yango te...", "Tension", "Battement de coeur"),
                SceneModel(2, 15, 45, "Esther", "Plan poitrine", "Panoramique", "Rappel de la foi", "Dieu est fidèle !", "Nzambe azali sembo !", "Espoir", "Nappe lumineuse"),
                SceneModel(3, 45, 60, "Narrateur", "Texte stylisé", "Slow motion", "Conclusion et verset", "Le Seigneur pourvoira.", "Nkolo akosala.", "Foi", "Accord céleste")
            )
        } else {
            parsed
        }
    }
    var scenes by remember { mutableStateOf(initialScenes) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Scénario Épisode ${episode.episodeNumber}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Text(
                            text = "Format vertical TikTok / Reels (Arc ${episode.arcNumber})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_editor_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fermer",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = titleFr,
                            onValueChange = { titleFr = it },
                            label = { Text("Titre de l'épisode (Français)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_title_fr")
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = titleLn,
                            onValueChange = { titleLn = it },
                            label = { Text("Titre de l'épisode (Lingala)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        Column {
                            Text(
                                text = "Durée visée : $durationSec secondes (TikTok/Reels)",
                                style = MaterialTheme.typography.labelMedium,
                                color = GoldPrimary
                            )
                            Slider(
                                value = durationSec.toFloat(),
                                onValueChange = { durationSec = it.toInt() },
                                valueRange = 45f..90f,
                                steps = 44,
                                modifier = Modifier.testTag("duration_slider")
                            )
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = primaryTheme,
                            onValueChange = { primaryTheme = it },
                            label = { Text("Thème Principal (Foi, Pauvreté, Tentation, Pardon...)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = synopsis,
                            onValueChange = { synopsis = it },
                            label = { Text("Synopsis narratif") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1724)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "⚡ Hook TikTok (0-3 premières secondes)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = hookFr,
                                    onValueChange = { hookFr = it },
                                    label = { Text("Phrase d'accroche (FR) - ex: 800$ ou ma mère meurt") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = hookLn,
                                    onValueChange = { hookLn = it },
                                    label = { Text("Phrase d'accroche (Lingala)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1724)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "📖 Verset Biblique d'Impact (Fin d'épisode)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = bibleVerseRef,
                                    onValueChange = { bibleVerseRef = it },
                                    label = { Text("Référence (ex: Proverbes 10:22)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = bibleVerseFr,
                                    onValueChange = { bibleVerseFr = it },
                                    label = { Text("Texte biblique (Français)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = bibleVerseLn,
                                    onValueChange = { bibleVerseLn = it },
                                    label = { Text("Texte biblique (Lingala)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    // Scène list
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "🎬 Découpage des Scènes (${scenes.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Button(
                                onClick = {
                                    val newNum = scenes.size + 1
                                    val lastEnd = scenes.lastOrNull()?.timeEndSec ?: 0
                                    scenes = scenes + SceneModel(
                                        sceneNumber = newNum,
                                        timeStartSec = lastEnd,
                                        timeEndSec = (lastEnd + 15).coerceAtMost(durationSec),
                                        character = "Samuel",
                                        cameraShot = "Gros plan",
                                        cameraMovement = "Zoom avant lent",
                                        actionDescription = "Nouvelle action dramatique",
                                        dialogueFr = "Dialogue en français...",
                                        dialogueLn = "Dialogue en lingala...",
                                        emotion = "Intense",
                                        sfxAudio = "Nappe dramatique"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1724))
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ajouter Scène")
                            }
                        }
                    }

                    itemsIndexed(scenes) { index, scene ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF15101A)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Scène ${scene.sceneNumber} (${scene.timeStartSec}s - ${scene.timeEndSec}s)",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldPrimary
                                    )
                                    if (scenes.size > 1) {
                                        IconButton(
                                            onClick = {
                                                scenes = scenes.filterIndexed { i, _ -> i != index }
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Supprimer scène",
                                                tint = Color(0xFFE57373),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = scene.character,
                                        onValueChange = { updated ->
                                            scenes = scenes.toMutableList().also {
                                                it[index] = scene.copy(character = updated)
                                            }
                                        },
                                        label = { Text("Personnage") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = scene.cameraMovement,
                                        onValueChange = { updated ->
                                            scenes = scenes.toMutableList().also {
                                                it[index] = scene.copy(cameraMovement = updated)
                                            }
                                        },
                                        label = { Text("Caméra / Effet") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = scene.dialogueFr,
                                    onValueChange = { updated ->
                                        scenes = scenes.toMutableList().also {
                                            it[index] = scene.copy(dialogueFr = updated)
                                        }
                                    },
                                    label = { Text("Dialogue Français") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = scene.dialogueLn,
                                    onValueChange = { updated ->
                                        scenes = scenes.toMutableList().also {
                                            it[index] = scene.copy(dialogueLn = updated)
                                        }
                                    },
                                    label = { Text("Dialogue Lingala") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2
                                )
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = visualPrompt,
                            onValueChange = { visualPrompt = it },
                            label = { Text("Prompt Visuel IA 0$ (Bing Image Creator / Leonardo)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = montageGuide,
                            onValueChange = { montageGuide = it },
                            label = { Text("Guide de Montage CapCut (Effets 3D Zoom & transitions)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("cancel_button")
                    ) {
                        Text("Annuler")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            val updatedEntity = episode.copy(
                                titleFr = titleFr,
                                titleLn = titleLn,
                                synopsis = synopsis,
                                durationSeconds = durationSec,
                                primaryTheme = primaryTheme,
                                bibleVerseRef = bibleVerseRef,
                                bibleVerseFr = bibleVerseFr,
                                bibleVerseLn = bibleVerseLn,
                                hookFr = hookFr,
                                hookLn = hookLn,
                                visualPrompt = visualPrompt,
                                montageGuide = montageGuide,
                                scenesJson = SceneModel.serializeList(scenes),
                                updatedAt = System.currentTimeMillis()
                            )
                            onSave(updatedEntity)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1724)),
                        modifier = Modifier.testTag("save_episode_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sauvegarder l'Épisode", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
