package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Palette Le Prix de la Foi - Drame Chrétien Africain (KUMBA CAST)
val GoldPrimary = Color(0xFFF3B33D)
val GoldOnPrimary = Color(0xFF241500)
val GoldContainer = Color(0xFF472D00)
val GoldOnContainer = Color(0xFFFFDF9E)

val TerracottaSecondary = Color(0xFFE07A4F)
val TerracottaOnSecondary = Color(0xFFFFFFFF)
val TerracottaContainer = Color(0xFF451A08)
val TerracottaOnContainer = Color(0xFFFFDBCF)

val CrimsonDilemma = Color(0xFFC74343)
val CrimsonContainer = Color(0xFF481010)

val DramaBackgroundDark = Color(0xFF0F0C10)
val DramaSurfaceDark = Color(0xFF19141D)
val DramaSurfaceVariantDark = Color(0xFF27202B)
val DramaCardSurface = Color(0xFF201A24)

val DramaTextPrimary = Color(0xFFF6EFE9)
val DramaTextSecondary = Color(0xFFC8BEB4)
val DramaTextMuted = Color(0xFF8F847B)

val LingalaGreen = Color(0xFF2E7D32)
val LingalaGreenLight = Color(0xFF81C784)
val LingalaGreenContainer = Color(0xFF103314)

val TikTokBadgeColor = Color(0xFF00F2FE)
val ReelsBadgeColor = Color(0xFFFD1D1D)

val GoldAccent = Color(0xFFFFC107)
