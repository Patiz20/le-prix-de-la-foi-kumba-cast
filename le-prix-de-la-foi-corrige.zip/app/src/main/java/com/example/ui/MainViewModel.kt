package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.CharacterModel
import com.example.data.model.CharactersBible
import com.example.data.model.EpisodeEntity
import com.example.data.model.ProductionData
import com.example.data.model.SceneModel
import com.example.data.model.StoryArc
import com.example.data.repository.EpisodeRepository
import com.example.video.AudioRecordingManager
import com.example.video.BibleSpeechFormatter
import com.example.video.LocalMp4VideoExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

enum class StudioTab(val label: String) {
    EPISODES("Épisodes (150)"),
    REEL_PLAYER("Lecteur Reel 9:16"),
    CHARACTERS("Bible Personnages"),
    PRODUCTION_GUIDE("Méthode 0$ KUMBA")
}

enum class ReelLanguageMode(val label: String) {
    FRENCH("Français"),
    LINGALA("Lingala"),
    DUAL("Bilingue (FR + LN)")
}

data class StudioUiState(
    val selectedArc: Int? = null,
    val selectedStatus: String? = null,
    val searchQuery: String = "",
    val activeTab: StudioTab = StudioTab.EPISODES,
    val activeEpisodeForReelId: Long? = null,
    val editingEpisode: EpisodeEntity? = null,
    val isReelPlaying: Boolean = false,
    val reelTimeSeconds: Float = 0f,
    val reelLanguageMode: ReelLanguageMode = ReelLanguageMode.FRENCH,
    val isTeleprompterOpen: Boolean = false,
    val isTtsActive: Boolean = false,
    val isAutoNarrationEnabled: Boolean = true,
    val isExportingVideo: Boolean = false,
    val exportProgress: Float = 0f,
    val exportedVideoFile: File? = null,
    val showExportModal: Boolean = false,
    val isRecordingVoice: Boolean = false,
    val isPlayingVoice: Boolean = false,
    val hasVoiceRecording: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository: EpisodeRepository
    private val audioManager = AudioRecordingManager(application)
    private val videoExporter = LocalMp4VideoExporter(application)

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var playbackJob: Job? = null

    val rawEpisodes: StateFlow<List<EpisodeEntity>>

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    init {
        val database = AppDatabase.getInstance(application)
        repository = EpisodeRepository(database.episodeDao())
        rawEpisodes = repository.allEpisodes.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        tts = TextToSpeech(application, this)
        viewModelScope.launch {
            repository.ensureInitialEpisodesLoaded()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.FRENCH)
            isTtsReady = (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED)
            tts?.setSpeechRate(0.92f)
            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _uiState.value = _uiState.value.copy(isTtsActive = true)
                }
                override fun onDone(utteranceId: String?) {
                    _uiState.value = _uiState.value.copy(isTtsActive = false)
                }
                override fun onError(utteranceId: String?) {
                    _uiState.value = _uiState.value.copy(isTtsActive = false)
                }
            })
        }
    }

    val filteredEpisodes: StateFlow<List<EpisodeEntity>> = combine(
        rawEpisodes,
        _uiState
    ) { episodes, state ->
        episodes.filter { episode ->
            val matchesArc = state.selectedArc == null || episode.arcNumber == state.selectedArc
            val matchesStatus = state.selectedStatus == null || episode.status == state.selectedStatus
            val matchesSearch = state.searchQuery.isBlank() ||
                    episode.titleFr.contains(state.searchQuery, ignoreCase = true) ||
                    episode.titleLn.contains(state.searchQuery, ignoreCase = true) ||
                    episode.primaryTheme.contains(state.searchQuery, ignoreCase = true) ||
                    episode.synopsis.contains(state.searchQuery, ignoreCase = true) ||
                    episode.bibleVerseRef.contains(state.searchQuery, ignoreCase = true) ||
                    "Épisode ${episode.episodeNumber}".contains(state.searchQuery, ignoreCase = true)
            matchesArc && matchesStatus && matchesSearch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: StudioTab) {
        _uiState.value = _uiState.value.copy(activeTab = tab)
        if (tab != StudioTab.REEL_PLAYER) {
            pauseReel()
        }
    }

    fun setSelectedArc(arc: Int?) {
        _uiState.value = _uiState.value.copy(selectedArc = arc)
    }

    fun setSelectedStatus(status: String?) {
        _uiState.value = _uiState.value.copy(selectedStatus = status)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun selectEpisodeForReel(episode: EpisodeEntity) {
        pauseReel()
        val hasRecording = audioManager.hasRecording(episode.episodeNumber)
        _uiState.value = _uiState.value.copy(
            activeEpisodeForReelId = episode.id,
            reelTimeSeconds = 0f,
            activeTab = StudioTab.REEL_PLAYER,
            hasVoiceRecording = hasRecording
        )
    }

    fun toggleReelPlayback() {
        val currentEpisode = getActiveReelEpisode() ?: return
        if (_uiState.value.isReelPlaying) {
            pauseReel()
        } else {
            playReel(currentEpisode)
        }
    }

    private fun playReel(episode: EpisodeEntity) {
        playbackJob?.cancel()
        _uiState.value = _uiState.value.copy(isReelPlaying = true)
        val scenes = SceneModel.parseList(episode.scenesJson)
        val dynamicTimeline = com.example.video.SceneCinematics.computeDynamicTimeline(
            scenes,
            episode.durationSeconds.toFloat(),
            episode.bibleVerseFr,
            episode.ctaFr
        )
        val maxDuration = maxOf(episode.durationSeconds.toFloat(), dynamicTimeline.totalDurationSec).coerceAtLeast(30f)

        if (_uiState.value.hasVoiceRecording) {
            audioManager.startPlayback(episode.episodeNumber) {
                _uiState.value = _uiState.value.copy(isPlayingVoice = false)
            }
        }

        var lastSpokenSceneNumber = -1
        var hasSpokenClimax = false

        playbackJob = viewModelScope.launch {
            while (_uiState.value.isReelPlaying) {
                delay(100)
                val newTime = _uiState.value.reelTimeSeconds + 0.1f
                if (newTime >= maxDuration) {
                    _uiState.value = _uiState.value.copy(
                        reelTimeSeconds = maxDuration,
                        isReelPlaying = false
                    )
                    stopTts()
                    audioManager.stopPlayback()
                    break
                } else {
                    _uiState.value = _uiState.value.copy(reelTimeSeconds = newTime)

                    // Automatic Continuous Narration Sync (when no voice recording is playing)
                    if (!_uiState.value.hasVoiceRecording && _uiState.value.isAutoNarrationEnabled) {
                        val resolution = com.example.video.SceneCinematics.resolveTimeline(scenes, maxDuration, newTime)
                        if (resolution.isClimax && !hasSpokenClimax) {
                            hasSpokenClimax = true
                            val verseText = com.example.video.BibleSpeechFormatter.buildSpokenClimax(
                                episode.bibleVerseRef,
                                episode.bibleVerseFr,
                                episode.bibleVerseLn,
                                episode.ctaFr,
                                _uiState.value.reelLanguageMode == ReelLanguageMode.LINGALA
                            )
                            speakDialogueInternal(verseText)
                        } else if (!resolution.isClimax && resolution.scene != null && resolution.scene.sceneNumber != lastSpokenSceneNumber) {
                            lastSpokenSceneNumber = resolution.scene.sceneNumber
                            val dialogueToSpeak = when (_uiState.value.reelLanguageMode) {
                                ReelLanguageMode.LINGALA -> if (resolution.scene.dialogueLn.isNotBlank()) resolution.scene.dialogueLn else resolution.scene.dialogueFr
                                else -> resolution.scene.dialogueFr
                            }
                            speakDialogueInternal(dialogueToSpeak)
                        }
                    }
                }
            }
        }
    }

    private fun speakDialogueInternal(text: String) {
        if (!isTtsReady || !_uiState.value.isAutoNarrationEnabled) return
        val speechText = com.example.video.BibleSpeechFormatter.formatForSpeech(text)
        tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "dialogue_${System.currentTimeMillis()}")
        _uiState.value = _uiState.value.copy(isTtsActive = true)
    }

    fun toggleAutoNarration() {
        val newState = !_uiState.value.isAutoNarrationEnabled
        _uiState.value = _uiState.value.copy(isAutoNarrationEnabled = newState)
        if (!newState) {
            stopTts()
            Toast.makeText(getApplication(), "Narration vocale désactivée", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(getApplication(), "Narration vocale continue activée", Toast.LENGTH_SHORT).show()
            val currentEpisode = getActiveReelEpisode()
            if (currentEpisode != null && _uiState.value.isReelPlaying) {
                val scenes = SceneModel.parseList(currentEpisode.scenesJson)
                val res = com.example.video.SceneCinematics.resolveTimeline(scenes, currentEpisode.durationSeconds.toFloat(), _uiState.value.reelTimeSeconds)
                val dialogue = if (res.isClimax) {
                    com.example.video.BibleSpeechFormatter.buildSpokenClimax(
                        currentEpisode.bibleVerseRef,
                        currentEpisode.bibleVerseFr,
                        currentEpisode.bibleVerseLn,
                        currentEpisode.ctaFr,
                        _uiState.value.reelLanguageMode == ReelLanguageMode.LINGALA
                    )
                } else {
                    when (_uiState.value.reelLanguageMode) {
                        ReelLanguageMode.LINGALA -> if (res.scene?.dialogueLn?.isNotBlank() == true) res.scene.dialogueLn else (res.scene?.dialogueFr ?: "")
                        else -> res.scene?.dialogueFr ?: ""
                    }
                }
                if (dialogue.isNotBlank()) speakDialogueInternal(dialogue)
            }
        }
    }

    fun pauseReel() {
        playbackJob?.cancel()
        _uiState.value = _uiState.value.copy(isReelPlaying = false)
        audioManager.stopPlayback()
        stopTts()
    }

    fun seekReel(seconds: Float) {
        val currentEpisode = getActiveReelEpisode() ?: return
        val scenes = SceneModel.parseList(currentEpisode.scenesJson)
        val dynamicTimeline = com.example.video.SceneCinematics.computeDynamicTimeline(
            scenes,
            currentEpisode.durationSeconds.toFloat(),
            currentEpisode.bibleVerseFr,
            currentEpisode.ctaFr
        )
        val maxDuration = maxOf(currentEpisode.durationSeconds.toFloat(), dynamicTimeline.totalDurationSec).coerceAtLeast(30f)
        val clamped = seconds.coerceIn(0f, maxDuration)
        _uiState.value = _uiState.value.copy(reelTimeSeconds = clamped)
        stopTts()
        audioManager.stopPlayback()
        if (_uiState.value.isReelPlaying) {
            val res = com.example.video.SceneCinematics.resolveTimeline(scenes, maxDuration, clamped)
            val dialogue = if (res.isClimax) {
                com.example.video.BibleSpeechFormatter.buildSpokenClimax(
                    currentEpisode.bibleVerseRef,
                    currentEpisode.bibleVerseFr,
                    currentEpisode.bibleVerseLn,
                    currentEpisode.ctaFr,
                    _uiState.value.reelLanguageMode == ReelLanguageMode.LINGALA
                )
            } else {
                when (_uiState.value.reelLanguageMode) {
                    ReelLanguageMode.LINGALA -> if (res.scene?.dialogueLn?.isNotBlank() == true) res.scene.dialogueLn else (res.scene?.dialogueFr ?: "")
                    else -> res.scene?.dialogueFr ?: ""
                }
            }
            if (dialogue.isNotBlank() && _uiState.value.isAutoNarrationEnabled) {
                speakDialogueInternal(dialogue)
            }
        }
    }

    fun setReelLanguageMode(mode: ReelLanguageMode) {
        _uiState.value = _uiState.value.copy(reelLanguageMode = mode)
    }

    fun toggleTeleprompter() {
        _uiState.value = _uiState.value.copy(isTeleprompterOpen = !_uiState.value.isTeleprompterOpen)
    }

    fun speakCurrentSceneText(text: String) {
        if (!isTtsReady) {
            Toast.makeText(getApplication(), "Synthèse vocale indisponible", Toast.LENGTH_SHORT).show()
            return
        }
        val speechText = com.example.video.BibleSpeechFormatter.formatForSpeech(text)
        tts?.stop()
        tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "scene_tts")
        _uiState.value = _uiState.value.copy(isTtsActive = true)
    }

    fun stopTts() {
        tts?.stop()
        _uiState.value = _uiState.value.copy(isTtsActive = false)
    }

    fun openEpisodeEditor(episode: EpisodeEntity?) {
        _uiState.value = _uiState.value.copy(editingEpisode = episode)
    }

    fun closeEpisodeEditor() {
        _uiState.value = _uiState.value.copy(editingEpisode = null)
    }

    fun saveEditingEpisode(episode: EpisodeEntity) {
        viewModelScope.launch {
            repository.saveEpisode(episode)
            closeEpisodeEditor()
            Toast.makeText(getApplication(), "Épisode ${episode.episodeNumber} sauvegardé !", Toast.LENGTH_SHORT).show()
        }
    }

    fun createNextEpisode() {
        viewModelScope.launch {
            val newEpisode = repository.createNextEpisodeSlot()
            Toast.makeText(
                getApplication(),
                "Épisode ${newEpisode.episodeNumber} créé avec succès !",
                Toast.LENGTH_SHORT
            ).show()
            openEpisodeEditor(newEpisode)
        }
    }

    fun generateAllEpisodesTo150() {
        viewModelScope.launch {
            val createdCount = repository.generateEpisodesUpTo(150)
            if (createdCount > 0) {
                Toast.makeText(
                    getApplication(),
                    "150 épisodes générés avec succès dans les 5 Arcs narratifs !",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    getApplication(),
                    "Les 150 épisodes sont déjà tous générés !",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun generateNextBatch(count: Int = 10) {
        viewModelScope.launch {
            val currentCount = repository.getCount()
            val target = (currentCount + count).coerceAtMost(150)
            val createdCount = repository.generateEpisodesUpTo(target)
            Toast.makeText(
                getApplication(),
                "$createdCount nouveaux épisodes générés (Total : $target / 150) !",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun toggleFavorite(episode: EpisodeEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(episode.id, episode.isFavorite)
        }
    }

    fun updateStatus(episode: EpisodeEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateStatus(episode.id, newStatus)
            Toast.makeText(getApplication(), "Statut mis à jour : $newStatus", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteEpisode(episode: EpisodeEntity) {
        viewModelScope.launch {
            repository.deleteEpisode(episode)
            if (_uiState.value.activeEpisodeForReelId == episode.id) {
                _uiState.value = _uiState.value.copy(activeEpisodeForReelId = null)
            }
            Toast.makeText(getApplication(), "Épisode ${episode.episodeNumber} supprimé", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(getApplication(), "$label copié dans le presse-papier !", Toast.LENGTH_SHORT).show()
    }

    // Voice recording rehearsal features
    fun startVoiceRecording(episodeNumber: Int) {
        pauseReel()
        val success = audioManager.startRecording(episodeNumber)
        if (success) {
            _uiState.value = _uiState.value.copy(isRecordingVoice = true)
            Toast.makeText(getApplication(), "Enregistrement voix démarré...", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(getApplication(), "Erreur au démarrage de l'enregistrement", Toast.LENGTH_SHORT).show()
        }
    }

    fun stopVoiceRecording(episodeNumber: Int) {
        audioManager.stopRecording()
        val hasFile = audioManager.hasRecording(episodeNumber)
        _uiState.value = _uiState.value.copy(
            isRecordingVoice = false,
            hasVoiceRecording = hasFile
        )
        if (hasFile) {
            Toast.makeText(getApplication(), "Voix off enregistrée pour l'Épisode $episodeNumber !", Toast.LENGTH_SHORT).show()
        }
    }

    fun playVoiceRecording(episodeNumber: Int) {
        pauseReel()
        audioManager.startPlayback(episodeNumber) {
            _uiState.value = _uiState.value.copy(isPlayingVoice = false)
        }
        _uiState.value = _uiState.value.copy(isPlayingVoice = true)
    }

    fun stopVoicePlayback() {
        audioManager.stopPlayback()
        _uiState.value = _uiState.value.copy(isPlayingVoice = false)
    }

    fun deleteVoiceRecording(episodeNumber: Int) {
        audioManager.deleteRecording(episodeNumber)
        _uiState.value = _uiState.value.copy(
            isPlayingVoice = false,
            hasVoiceRecording = false
        )
        Toast.makeText(getApplication(), "Enregistrement audio supprimé", Toast.LENGTH_SHORT).show()
    }

    // Hybrid Video Clip Management (KUMBA CAST Hybrid Approach)
    fun attachVideoClipToScene(episodeId: Long, sceneNumber: Int, sourceUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val episode = rawEpisodes.value.firstOrNull { it.id == episodeId } ?: return@launch
                val scenes = SceneModel.parseList(episode.scenesJson).toMutableList()
                val sceneIndex = scenes.indexOfFirst { it.sceneNumber == sceneNumber }
                if (sceneIndex == -1) return@launch

                val videoDir = File(context.filesDir, "scene_videos").apply { if (!exists()) mkdirs() }
                val destFile = File(videoDir, "ep_${episode.episodeNumber}_sc_${sceneNumber}.mp4")

                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }

                val updatedScene = scenes[sceneIndex].copy(videoUri = destFile.absolutePath)
                scenes[sceneIndex] = updatedScene

                val updatedEpisode = episode.copy(
                    scenesJson = SceneModel.serializeList(scenes),
                    updatedAt = System.currentTimeMillis()
                )
                repository.saveEpisode(updatedEpisode)

                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Clip MP4 lié à la Scène $sceneNumber (Épisode ${episode.episodeNumber}) !",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        getApplication(),
                        "Erreur import clip : ${e.localizedMessage}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    fun removeVideoClipFromScene(episodeId: Long, sceneNumber: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val episode = rawEpisodes.value.firstOrNull { it.id == episodeId } ?: return@launch
                val scenes = SceneModel.parseList(episode.scenesJson).toMutableList()
                val sceneIndex = scenes.indexOfFirst { it.sceneNumber == sceneNumber }
                if (sceneIndex == -1) return@launch

                val oldUri = scenes[sceneIndex].videoUri
                if (!oldUri.isNullOrBlank()) {
                    try { File(oldUri).delete() } catch (ignored: Exception) {}
                }

                scenes[sceneIndex] = scenes[sceneIndex].copy(videoUri = null)
                val updatedEpisode = episode.copy(
                    scenesJson = SceneModel.serializeList(scenes),
                    updatedAt = System.currentTimeMillis()
                )
                repository.saveEpisode(updatedEpisode)

                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        getApplication(),
                        "Clip retiré de la Scène $sceneNumber (Retour à l'animation 2.5D)",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private suspend fun generateTtsAudioForEpisode(episode: EpisodeEntity): File? = withContext(Dispatchers.IO) {
        val ttsInstance = tts ?: return@withContext null
        if (!isTtsReady) return@withContext null

        val scenes = SceneModel.parseList(episode.scenesJson)
        val sb = StringBuilder()
        for (sc in scenes) {
            val dialogue = if (_uiState.value.reelLanguageMode == ReelLanguageMode.LINGALA && sc.dialogueLn.isNotBlank()) {
                sc.dialogueLn
            } else {
                sc.dialogueFr
            }
            if (dialogue.isNotBlank()) {
                sb.append(BibleSpeechFormatter.formatForSpeech(dialogue)).append(". ")
            }
        }
        val climaxSpoken = BibleSpeechFormatter.buildSpokenClimax(
            episode.bibleVerseRef,
            episode.bibleVerseFr,
            episode.bibleVerseLn,
            episode.ctaFr,
            _uiState.value.reelLanguageMode == ReelLanguageMode.LINGALA
        )
        sb.append(climaxSpoken)

        val textToSpeak = sb.toString().trim()
        if (textToSpeak.isBlank()) return@withContext null

        val tempAudio = File(getApplication<Application>().cacheDir, "tts_narration_${episode.episodeNumber}_${System.currentTimeMillis()}.wav")
        try {
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "export_tts_${episode.episodeNumber}")
            }
            val result = ttsInstance.synthesizeToFile(textToSpeak, params, tempAudio, "export_tts_${episode.episodeNumber}")
            if (result == TextToSpeech.SUCCESS) {
                var waitCount = 0
                while ((!tempAudio.exists() || tempAudio.length() == 0L) && waitCount < 35) {
                    kotlinx.coroutines.delay(100)
                    waitCount++
                }
                if (tempAudio.exists() && tempAudio.length() > 0) {
                    return@withContext tempAudio
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext null
    }

    // MP4 Video Export features
    fun openExportModal() {
        _uiState.value = _uiState.value.copy(showExportModal = true)
    }

    fun closeExportModal() {
        _uiState.value = _uiState.value.copy(showExportModal = false)
    }

    fun exportCurrentEpisodeToMp4(includeVoice: Boolean) {
        val episode = getActiveReelEpisode() ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isExportingVideo = true,
                exportProgress = 0f,
                exportedVideoFile = null
            )

            // 1. Check user recorded voice
            // 2. If absent, synthesize spoken narration/dialogues via TTS so dialogues are actually in the MP4!
            val voiceFile: File? = if (includeVoice && audioManager.hasRecording(episode.episodeNumber)) {
                audioManager.getAudioFile(episode.episodeNumber)
            } else if (includeVoice) {
                generateTtsAudioForEpisode(episode)
            } else {
                null
            }

            val result = videoExporter.exportEpisode(
                episode = episode,
                languageMode = _uiState.value.reelLanguageMode,
                audioVoiceFile = voiceFile,
                onProgress = { progress ->
                    _uiState.value = _uiState.value.copy(exportProgress = progress)
                }
            )

            result.onSuccess { file ->
                _uiState.value = _uiState.value.copy(
                    isExportingVideo = false,
                    exportProgress = 1f,
                    exportedVideoFile = file
                )
                repository.updateStatus(episode.id, "MONTE")
                Toast.makeText(getApplication(), "Vidéo MP4 9:16 exportée avec dialogues réels !", Toast.LENGTH_LONG).show()
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    isExportingVideo = false,
                    exportProgress = 0f
                )
                Toast.makeText(getApplication(), "Erreur export : ${error.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun shareExportedVideo(file: File) {
        try {
            val context = getApplication<Application>()
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val episode = getActiveReelEpisode()
            val epNum = episode?.episodeNumber ?: 1
            val title = episode?.titleFr ?: "Le Prix de la Foi"
            val verse = episode?.bibleVerseRef ?: ""

            val shareText = """
                🎬 LE PRIX DE LA FOI — Épisode $epNum : $title
                Production KUMBA CAST (Drame chrétien urbain)
                📖 $verse
                À découvrir sur nos chaînes officielles !
                #LePrixDeLaFoi #KumbaCast #DrameChretien #Kinshasa #FoiEtEpreuve
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "LE PRIX DE LA FOI - KUMBA CAST")
                putExtra(Intent.EXTRA_TEXT, shareText)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // WhatsApp specific target or generic chooser
            val chooser = Intent.createChooser(intent, "Partager sur WhatsApp / TikTok / Reels").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(getApplication(), "Erreur de partage : ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun getActiveReelEpisode(): EpisodeEntity? {
        val id = _uiState.value.activeEpisodeForReelId
        val list = rawEpisodes.value
        return if (id != null) {
            list.firstOrNull { it.id == id } ?: list.firstOrNull()
        } else {
            list.firstOrNull()
        }
    }

    override fun onCleared() {
        playbackJob?.cancel()
        tts?.stop()
        tts?.shutdown()
        audioManager.stopPlayback()
        audioManager.stopRecording()
        super.onCleared()
    }
}
