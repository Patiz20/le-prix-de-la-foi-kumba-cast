package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DramaColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = GoldOnPrimary,
    primaryContainer = GoldContainer,
    onPrimaryContainer = GoldOnContainer,
    secondary = TerracottaSecondary,
    onSecondary = TerracottaOnSecondary,
    secondaryContainer = TerracottaContainer,
    onSecondaryContainer = TerracottaOnContainer,
    tertiary = CrimsonDilemma,
    onTertiary = Color.White,
    tertiaryContainer = CrimsonContainer,
    onTertiaryContainer = Color(0xFFFFDAD6),
    background = DramaBackgroundDark,
    onBackground = DramaTextPrimary,
    surface = DramaSurfaceDark,
    onSurface = DramaTextPrimary,
    surfaceVariant = DramaSurfaceVariantDark,
    onSurfaceVariant = DramaTextSecondary,
    outline = Color(0xFF4C434F)
)

@Composable
fun LePrixDeLaFoiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We intentionally maintain a rich cinematic dark aesthetic fitting vertical reel theater & drama
    MaterialTheme(
        colorScheme = DramaColorScheme,
        typography = Typography,
        content = content
    )
}
