package com.example.ui.screens

import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.model.EpisodeEntity
import com.example.data.model.SceneModel
import com.example.ui.ReelLanguageMode
import com.example.ui.StudioUiState
import com.example.ui.theme.CrimsonDilemma
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.LingalaGreen
import com.example.ui.theme.TerracottaSecondary
import com.example.video.SceneCinematics
import java.io.File
import kotlin.math.sin

@Composable
fun ReelPlayerScreen(
    episode: EpisodeEntity?,
    uiState: StudioUiState,
    onTogglePlayback: () -> Unit,
    onSeek: (Float) -> Unit,
    onToggleLanguage: (ReelLanguageMode) -> Unit,
    onToggleFavorite: (EpisodeEntity) -> Unit,
    onSpeakScene: (String) -> Unit,
    onStopTts: () -> Unit,
    onToggleAutoNarration: () -> Unit = {},
    onToggleTeleprompter: () -> Unit,
    onCopyScript: (EpisodeEntity) -> Unit,
    onOpenExportModal: () -> Unit,
    onStartVoiceRecording: () -> Unit,
    onStopVoiceRecording: () -> Unit,
    onPlayVoiceRecording: () -> Unit,
    onStopVoicePlayback: () -> Unit,
    onDeleteVoiceRecording: () -> Unit,
    onBackToEpisodes: () -> Unit,
    onAttachVideoClip: (episodeId: Long, sceneNumber: Int, Uri) -> Unit = { _, _, _ -> },
    onRemoveVideoClip: (episodeId: Long, sceneNumber: Int) -> Unit = { _, _ -> },
    onCopyPrompt: (label: String, prompt: String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    if (episode == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Aucun épisode sélectionné",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onBackToEpisodes,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1724))
                ) {
                    Text("Choisir un Épisode")
                }
            }
        }
        return
    }

    val context = LocalContext.current
    val scenes = remember(episode.scenesJson) {
        SceneModel.parseList(episode.scenesJson)
    }

    val dynamicTimeline = remember(scenes, episode.durationSeconds, episode.bibleVerseFr, episode.ctaFr) {
        SceneCinematics.computeDynamicTimeline(scenes, episode.durationSeconds.toFloat(), episode.bibleVerseFr, episode.ctaFr)
    }
    val totalDuration = maxOf(episode.durationSeconds.toFloat(), dynamicTimeline.totalDurationSec).coerceAtLeast(30f)
    val currentTime = uiState.reelTimeSeconds

    val resolution = remember(currentTime, scenes, totalDuration) {
        SceneCinematics.resolveTimeline(scenes, totalDuration, currentTime)
    }

    val currentScene = resolution.scene
    val isEndVerseTime = resolution.isClimax

    // Check if current scene has an imported MP4 video clip that actually exists
    val currentVideoPath = currentScene?.videoUri
    val hasValidClip = remember(currentVideoPath) {
        if (!currentVideoPath.isNullOrBlank()) {
            val f = File(currentVideoPath)
            f.exists() && f.length() > 0
        } else false
    }

    val validClipsCount = remember(scenes) {
        scenes.count { !it.videoUri.isNullOrBlank() && File(it.videoUri).exists() }
    }

    // Media3 ExoPlayer Instance for real MP4 scene playback
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
            playWhenReady = true
            volume = 0f // Audio is handled seamlessly by TTS / voice rehearsal
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    LaunchedEffect(currentVideoPath, hasValidClip) {
        if (hasValidClip && currentVideoPath != null) {
            val uri = if (currentVideoPath.startsWith("content://") || currentVideoPath.startsWith("file://")) {
                Uri.parse(currentVideoPath)
            } else {
                Uri.fromFile(File(currentVideoPath))
            }
            val mediaItem = MediaItem.fromUri(uri)
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            if (uiState.isReelPlaying) {
                exoPlayer.play()
            } else {
                exoPlayer.pause()
            }
        } else {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
        }
    }

    LaunchedEffect(uiState.isReelPlaying, hasValidClip) {
        if (hasValidClip) {
            if (uiState.isReelPlaying) {
                exoPlayer.play()
            } else {
                exoPlayer.pause()
            }
        }
    }

    // State for interactive modals
    var targetSceneNumberForPick by remember { mutableStateOf<Int?>(null) }
    var promptDialogScene by remember { mutableStateOf<SceneModel?>(null) }
    var showAllClipsDialog by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val targetSceneNum = targetSceneNumberForPick ?: currentScene?.sceneNumber ?: 1
            onAttachVideoClip(episode.id, targetSceneNum, uri)
        }
    }

    // Smooth continuous cinematic camera motion for each scene with organic breathing and steadicam
    val cameraMotion = remember(resolution.scene, resolution.sceneProgress) {
        SceneCinematics.computeCameraMotion(
            resolution.scene?.cameraMovement ?: "Zoom avant lent",
            resolution.scene?.cameraShot ?: "Plan moyen",
            resolution.sceneProgress
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // Vertical 9:16 Canvas (responsive center container)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 480.dp)
                .clip(RoundedCornerShape(0.dp))
        ) {
            // RENDER STACK:
            if (hasValidClip) {
                // Real MP4 Video Clip with Media3 ExoPlayer
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                    },
                    update = { pv ->
                        if (pv.player != exoPlayer) {
                            pv.player = exoPlayer
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Procedural Visual Fallback:
                // Layer 1: Previous scene background if cross-fading
                if (resolution.crossFadeProgress < 1.0f && resolution.previousDrawableResId != resolution.currentDrawableResId) {
                    Image(
                        painter = painterResource(id = resolution.previousDrawableResId),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = cameraMotion.scale * 1.02f
                                scaleY = cameraMotion.scale * 1.02f
                                alpha = (1.0f - resolution.crossFadeProgress).coerceIn(0f, 1f)
                            },
                        contentScale = ContentScale.Crop
                    )
                }

                // Layer 2: Current Scene Visual with subtle motion
                val headTilt = 0.8f * sin(currentTime * 1.4f)
                val speechCadence = if (uiState.isTtsActive || uiState.isPlayingVoice) 2.0f * sin(currentTime * 24f) else 0f

                Image(
                    painter = painterResource(id = resolution.currentDrawableResId),
                    contentDescription = resolution.characterDisplay,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = cameraMotion.scale
                            scaleY = cameraMotion.scale
                            rotationZ = cameraMotion.rotationDeg + headTilt
                            translationX = (cameraMotion.translationXFraction * size.width) + cameraMotion.shakeXPx
                            translationY = (cameraMotion.translationYFraction * size.height) + cameraMotion.shakeYPx + speechCadence
                            alpha = if (resolution.previousDrawableResId != resolution.currentDrawableResId && resolution.crossFadeProgress < 1.0f) {
                                resolution.crossFadeProgress
                            } else {
                                cameraMotion.transitionAlpha
                            }
                        },
                    contentScale = ContentScale.Crop
                )

                // Layer 3: Atmospheric Floating Golden Light & Dust Particles Canvas
                androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                    val particles = SceneCinematics.getAtmosphericParticles(currentTime, 18)
                    for (p in particles) {
                        val px = p.xFraction * size.width
                        val py = p.yFraction * size.height
                        drawCircle(
                            color = Color(0xFFFFD54F).copy(alpha = (p.alpha * 0.65f)),
                            radius = p.radiusPx,
                            center = androidx.compose.ui.geometry.Offset(px, py)
                        )
                    }
                }
            }

            // Natural Cinematic Framing Overlay:
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Black.copy(alpha = 0.70f),
                                0.14f to Color.Black.copy(alpha = 0.25f),
                                0.25f to Color.Transparent,
                                0.55f to Color.Transparent,
                                0.75f to Color.Black.copy(alpha = 0.65f),
                                1.0f to Color.Black.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // Click anywhere on video to toggle play/pause
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { onTogglePlayback() }
            )

            // Top Header: Back Button, Episode Title & Arc, Clips Audit Pill
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, start = 12.dp, end = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onBackToEpisodes,
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            .testTag("reel_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour",
                            tint = Color.White
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "ÉPISODE ${episode.episodeNumber}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = episode.titleFr,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Language toggle pill
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier.clickable {
                            val next = when (uiState.reelLanguageMode) {
                                ReelLanguageMode.FRENCH -> ReelLanguageMode.LINGALA
                                ReelLanguageMode.LINGALA -> ReelLanguageMode.DUAL
                                ReelLanguageMode.DUAL -> ReelLanguageMode.FRENCH
                            }
                            onToggleLanguage(next)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = uiState.reelLanguageMode.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Top Header Pill: Quick status & trigger to view all episode clips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (validClipsCount > 0) LingalaGreen.copy(alpha = 0.25f) else Color(0xFF2C1D0E),
                        border = BorderStroke(1.dp, if (validClipsCount > 0) LingalaGreen else GoldPrimary.copy(alpha = 0.8f)),
                        modifier = Modifier
                            .clickable { showAllClipsDialog = true }
                            .testTag("top_clips_audit_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (validClipsCount > 0) Icons.Default.Movie else Icons.Default.VideoLibrary,
                                contentDescription = null,
                                tint = if (validClipsCount > 0) LingalaGreen else GoldPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (validClipsCount > 0) "🎬 $validClipsCount/${scenes.size} clips MP4 liés (ExoPlayer)" else "⚠️ 0/${scenes.size} clip lié • Gérer les clips",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (validClipsCount > 0) LingalaGreen else GoldPrimary
                            ) {
                                Text(
                                    text = "Ouvrir",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF1E1724),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            // Right-Side Action Bar: Like, TTS, Teleprompter, AI Prompt & MP4 Export
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 10.dp, bottom = 120.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ALL CLIPS DIALOG BUTTON
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { showAllClipsDialog = true },
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (validClipsCount > 0) LingalaGreen else GoldPrimary, CircleShape)
                            .testTag("reel_all_clips_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = "Gérer tous les clips",
                            tint = Color(0xFF1A1208)
                        )
                    }
                    Text(
                        text = "Clips ($validClipsCount/${scenes.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // AI Video Prompt & Clip Button for CURRENT scene
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { currentScene?.let { promptDialogScene = it } },
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (hasValidClip) LingalaGreen else Color.Black.copy(alpha = 0.7f), CircleShape)
                            .testTag("reel_ai_prompt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = "Prompt Scène",
                            tint = if (hasValidClip) Color(0xFF1A1208) else GoldPrimary
                        )
                    }
                    Text(
                        text = if (hasValidClip) "Clip lié" else "Prompt IA",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontSize = 10.sp
                    )
                }

                // Continuous Narration / Voice Rehearsal
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onToggleAutoNarration,
                        modifier = Modifier
                            .size(44.dp)
                            .background(
                                if (uiState.isAutoNarrationEnabled) GoldPrimary else Color.Black.copy(alpha = 0.6f),
                                CircleShape
                            )
                            .testTag("reel_tts_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Narration Vocale",
                            tint = if (uiState.isAutoNarrationEnabled) Color(0xFF1E1408) else Color.White
                        )
                    }
                    Text(
                        text = if (uiState.isAutoNarrationEnabled) (if (uiState.isTtsActive) "Voix on" else "Narration") else "Muet",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontSize = 10.sp
                    )
                }

                // Teleprompter / Rehearsal Mode
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onToggleTeleprompter,
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (uiState.isTeleprompterOpen) LingalaGreen else Color.Black.copy(alpha = 0.6f), CircleShape)
                            .testTag("reel_teleprompter_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Téléprompteur",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = "Prompteur",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontSize = 10.sp
                    )
                }

                // Favorite Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { onToggleFavorite(episode) },
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (episode.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favori",
                            tint = if (episode.isFavorite) CrimsonDilemma else Color.White
                        )
                    }
                    Text(
                        text = "Cœur",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontSize = 10.sp
                    )
                }

                // EXPORT MP4 BUTTON
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onOpenExportModal,
                        modifier = Modifier
                            .size(46.dp)
                            .background(GoldPrimary, CircleShape)
                            .testTag("reel_export_mp4_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Exporter Vidéo MP4",
                            tint = Color(0xFF1E1724)
                        )
                    }
                    Text(
                        text = "MP4 9:16",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            // PRIMARY SCENE ACTION & DOCK (Directly visible on the scene canvas)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 68.dp, bottom = 62.dp)
            ) {
                // Scene Carousel Chips (Allows clicking directly on any scene)
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(scenes) { sc ->
                        val isSelected = currentScene?.sceneNumber == sc.sceneNumber && !isEndVerseTime
                        val scHasClip = !sc.videoUri.isNullOrBlank() && File(sc.videoUri).exists()

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) (if (scHasClip) LingalaGreen else GoldPrimary) else Color.Black.copy(alpha = 0.75f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) Color.White else (if (scHasClip) LingalaGreen.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.25f))
                            ),
                            modifier = Modifier
                                .clickable { onSeek(sc.timeStartSec.toFloat()) }
                                .testTag("scene_chip_${sc.sceneNumber}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (scHasClip) "🎬" else "🖼️",
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Scène ${sc.sceneNumber}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color(0xFF1B1208) else Color.White,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isEndVerseTime) GoldPrimary else Color.Black.copy(alpha = 0.75f),
                            border = BorderStroke(1.dp, if (isEndVerseTime) Color.White else Color.White.copy(alpha = 0.25f)),
                            modifier = Modifier.clickable {
                                onSeek(dynamicTimeline.climaxStartSec)
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "📖 Verset", style = MaterialTheme.typography.labelSmall, color = if (isEndVerseTime) Color(0xFF1B1208) else GoldAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Active Scene Management Card with prominent actions & status warning
                if (!isEndVerseTime && currentScene != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.88f)),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (hasValidClip) LingalaGreen.copy(alpha = 0.8f) else GoldPrimary.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            // Scene identification & visual correspondence
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Scène ${currentScene.sceneNumber} (${currentScene.timeStartSec}s-${currentScene.timeEndSec}s) • ${currentScene.character}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Bold
                                )

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (hasValidClip) LingalaGreen.copy(alpha = 0.25f) else Color(0xFF6B2210)
                                ) {
                                    Text(
                                        text = if (hasValidClip) "🎬 MP4 Réel" else "⚠️ Image Fixe",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (hasValidClip) LingalaGreen else Color(0xFFFFB4A2),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            // Visual correspondence indicator (explains what is seen on screen)
                            Text(
                                text = "Visuel : ${SceneCinematics.describeVisualMatch(currentScene)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Action buttons: "Générer le prompt vidéo" & "Importer/Lier une vidéo MP4"
                            if (hasValidClip) {
                                // Real video clip active: preview, replace, remove
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = LingalaGreen.copy(alpha = 0.2f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LingalaGreen, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Véritable vidéo MP4 active (ExoPlayer)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = LingalaGreen,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Row {
                                            Text(
                                                text = "Remplacer",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = GoldAccent,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier
                                                    .clickable {
                                                        targetSceneNumberForPick = currentScene.sceneNumber
                                                        videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                                    }
                                                    .padding(horizontal = 4.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Retirer ✕",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CrimsonDilemma,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier
                                                    .clickable {
                                                        onRemoveVideoClip(episode.id, currentScene.sceneNumber)
                                                    }
                                                    .padding(horizontal = 4.dp)
                                            )
                                        }
                                    }
                                }
                            } else {
                                // No clip attached: CLEAR WARNING + PROMINENT BUTTONS
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF28180A),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Warning, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Rendu actuel : Image fixe animée (Aucune vidéo)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = GoldPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = "Le personnage est statique. Pour une vraie vidéo avec mouvements du visage, générez le clip puis liez le MP4.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontSize = 10.sp,
                                            lineHeight = 13.sp
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            // Action 1: "Générer le prompt vidéo"
                                            Button(
                                                onClick = { promptDialogScene = currentScene },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = GoldPrimary,
                                                    contentColor = Color(0xFF1E1724)
                                                ),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("btn_generate_prompt_${currentScene.sceneNumber}")
                                            ) {
                                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Prompt Vidéo IA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            // Action 2: "Importer/Lier une vidéo MP4"
                                            Button(
                                                onClick = {
                                                    targetSceneNumberForPick = currentScene.sceneNumber
                                                    videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = LingalaGreen,
                                                    contentColor = Color.Black
                                                ),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("btn_link_mp4_${currentScene.sceneNumber}")
                                            ) {
                                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Lier Clip MP4", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Subtitles
                            if (uiState.reelLanguageMode != ReelLanguageMode.LINGALA && currentScene.dialogueFr.isNotBlank()) {
                                Text(
                                    text = currentScene.dialogueFr,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 18.sp
                                )
                            }
                            if (uiState.reelLanguageMode != ReelLanguageMode.FRENCH && currentScene.dialogueLn.isNotBlank()) {
                                Text(
                                    text = currentScene.dialogueLn,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = LingalaGreen,
                                    fontStyle = FontStyle.Italic,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                } else if (isEndVerseTime) {
                    // Scripture Card Climax (End of Episode)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1408).copy(alpha = 0.95f)),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "📖 ${episode.bibleVerseRef}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "\"${episode.bibleVerseFr}\"",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                fontStyle = FontStyle.Italic
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "✨ ${episode.ctaFr}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                        }
                    }
                }
            }

            // Bottom Scrubber & Time Controls
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.98f))
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onTogglePlayback,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (uiState.isReelPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (uiState.isReelPlaying) "Pause" else "Lire",
                            tint = GoldPrimary
                        )
                    }

                    Slider(
                        value = currentTime,
                        onValueChange = onSeek,
                        valueRange = 0f..totalDuration,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = GoldPrimary,
                            activeTrackColor = GoldPrimary,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        )
                    )

                    val currentSec = currentTime.toInt()
                    val totalSec = totalDuration.toInt()
                    Text(
                        text = String.format("%02d:%02d / %02d:%02d", currentSec / 60, currentSec % 60, totalSec / 60, totalSec % 60),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Teleprompter Modal Drawer (if opened)
            AnimatedVisibility(
                visible = uiState.isTeleprompterOpen,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.94f))
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "🎙️ Téléprompteur & Découpage Scènes",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                            IconButton(onClick = onToggleTeleprompter) {
                                Icon(
                                    imageVector = Icons.Default.Replay,
                                    contentDescription = "Fermer",
                                    tint = Color.White
                                )
                            }
                        }

                        // Voice Recording Studio Control Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF231A2C)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Studio Enregistrement Voix (0 USD)",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldPrimary
                                    )
                                    if (uiState.hasVoiceRecording) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = LingalaGreen.copy(alpha = 0.25f)
                                        ) {
                                            Text(
                                                text = "Audio prêt",
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = LingalaGreen,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Lisez les répliques ci-dessous pendant l'enregistrement pour intégrer votre voix dans le MP4 final.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = {
                                            if (uiState.isRecordingVoice) {
                                                onStopVoiceRecording()
                                            } else {
                                                onStartVoiceRecording()
                                            }
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (uiState.isRecordingVoice) CrimsonDilemma else GoldPrimary,
                                            contentColor = if (uiState.isRecordingVoice) Color.White else Color(0xFF1A1208)
                                        )
                                    ) {
                                        Icon(
                                            imageVector = if (uiState.isRecordingVoice) Icons.Default.Stop else Icons.Default.Mic,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (uiState.isRecordingVoice) "Arrêter" else "Enregistrer",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    if (uiState.hasVoiceRecording) {
                                        OutlinedButton(
                                            onClick = {
                                                if (uiState.isPlayingVoice) {
                                                    onStopVoicePlayback()
                                                } else {
                                                    onPlayVoiceRecording()
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = if (uiState.isPlayingVoice) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (uiState.isPlayingVoice) "Stop" else "Écouter")
                                        }

                                        IconButton(
                                            onClick = onDeleteVoiceRecording,
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Supprimer",
                                                tint = CrimsonDilemma
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(scenes) { scene ->
                                val sceneHasClip = !scene.videoUri.isNullOrBlank() && File(scene.videoUri).exists()
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1624)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Scène ${scene.sceneNumber} (${scene.timeStartSec}s - ${scene.timeEndSec}s) • ${scene.character}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = GoldAccent,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (sceneHasClip) LingalaGreen.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.1f)
                                            ) {
                                                Text(
                                                    text = if (sceneHasClip) "🎬 Clip MP4" else "⚠️ Image Fixe",
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (sceneHasClip) LingalaGreen else Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = scene.dialogueFr,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (scene.dialogueLn.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = scene.dialogueLn,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = LingalaGreen
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    val prompt = scene.generateAiVideoPrompt(episode.episodeNumber, episode.primaryTheme)
                                                    onCopyPrompt("Prompt Scène ${scene.sceneNumber}", prompt)
                                                },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Prompt IA", fontSize = 11.sp)
                                            }

                                            Button(
                                                onClick = {
                                                    targetSceneNumberForPick = scene.sceneNumber
                                                    videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                                },
                                                modifier = Modifier.weight(1f),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (sceneHasClip) LingalaGreen else GoldPrimary,
                                                    contentColor = Color(0xFF1E1724)
                                                )
                                            ) {
                                                Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (sceneHasClip) "Remplacer" else "Lier Clip", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            if (sceneHasClip) {
                                                IconButton(
                                                    onClick = { onRemoveVideoClip(episode.id, scene.sceneNumber) },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Retirer clip", tint = CrimsonDilemma)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1E0A)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "Fin • Verset ${episode.bibleVerseRef}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = GoldPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "\"${episode.bibleVerseFr}\"",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White,
                                            fontStyle = FontStyle.Italic
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "✨ ${episode.ctaFr}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = GoldAccent
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // COMPLETE EPISODE CLIPS MANAGER DIALOG (Shows all scenes at a glance)
    if (showAllClipsDialog) {
        Dialog(onDismissRequest = { showAllClipsDialog = false }) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF181220)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Régie Vidéo • Épisode ${episode.episodeNumber}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "$validClipsCount sur ${scenes.size} scènes avec vidéo MP4 réelle",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (validClipsCount == scenes.size) LingalaGreen else GoldAccent
                                )
                            }
                        }
                        IconButton(onClick = { showAllClipsDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "💡 Approche Hybride KUMBA CAST : Vous pouvez tester un clip vidéo MP4 sur une seule scène (ex: Scène 1). Les autres scènes utilisent temporairement l'image de substitution en attendant vos prochains clips.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(10.dp),
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(scenes) { sc ->
                            val scHasClip = !sc.videoUri.isNullOrBlank() && File(sc.videoUri).exists()
                            Card(
                                colors = CardDefaults.cardColors(containerColor = if (scHasClip) Color(0xFF122316) else Color(0xFF22172A)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (scHasClip) LingalaGreen else Color.White.copy(alpha = 0.15f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Scène ${sc.sceneNumber} (${sc.timeStartSec}s-${sc.timeEndSec}s) : ${sc.character}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (scHasClip) LingalaGreen else GoldAccent
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (scHasClip) LingalaGreen else Color(0xFF6B2412)
                                        ) {
                                            Text(
                                                text = if (scHasClip) "🎬 MP4 Actif" else "⚠️ Image Fixe",
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (scHasClip) Color.Black else Color(0xFFFFB4A2),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Décor : ${SceneCinematics.describeVisualMatch(sc)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.sp
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "\"${sc.dialogueFr}\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White,
                                        fontStyle = FontStyle.Italic,
                                        fontSize = 11.sp,
                                        maxLines = 2
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                val prompt = sc.generateAiVideoPrompt(episode.episodeNumber, episode.primaryTheme)
                                                onCopyPrompt("Prompt Scène ${sc.sceneNumber}", prompt)
                                            },
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Prompt IA", fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                targetSceneNumberForPick = sc.sceneNumber
                                                videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (scHasClip) LingalaGreen else GoldPrimary,
                                                contentColor = Color(0xFF1E1724)
                                            ),
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (scHasClip) "Remplacer" else "Lier Clip MP4", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        if (scHasClip) {
                                            IconButton(
                                                onClick = { onRemoveVideoClip(episode.id, sc.sceneNumber) },
                                                modifier = Modifier.size(34.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Retirer clip", tint = CrimsonDilemma)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { showAllClipsDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1724)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Terminé", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // AI VIDEO PROMPT INSPECTOR & CLIP LINKER MODAL DIALOG
    promptDialogScene?.let { scene ->
        val fullPrompt = scene.generateAiVideoPrompt(episode.episodeNumber, episode.primaryTheme)
        val hasClip = !scene.videoUri.isNullOrBlank() && File(scene.videoUri).exists()

        Dialog(onDismissRequest = { promptDialogScene = null }) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1324)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Scène ${scene.sceneNumber} • Prompt Vidéo IA",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "${scene.character} • ${SceneCinematics.describeVisualMatch(scene)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GoldAccent
                                )
                            }
                        }
                        IconButton(onClick = { promptDialogScene = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Étapes gratuites 0$ pour animer cette scène :",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "1. Cliquez sur 'Copier le Prompt' ci-dessous.\n2. Ouvrez un outil gratuit : Kling AI (klingai.com) ou Hailuo MiniMax (hailuoai.video).\n3. Collez le prompt, générez la vidéo 9:16 et téléchargez le MP4 sur votre téléphone.\n4. Revenez ici et cliquez sur 'Lier le Clip MP4 Maintenant' !",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.6f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                    ) {
                        LazyColumn(modifier = Modifier.padding(10.dp)) {
                            item {
                                Text(
                                    text = fullPrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GoldAccent,
                                    lineHeight = 16.sp,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onCopyPrompt("Prompt Scène ${scene.sceneNumber}", fullPrompt)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1724)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copier le Prompt", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                targetSceneNumberForPick = scene.sceneNumber
                                promptDialogScene = null
                                videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LingalaGreen, contentColor = Color.Black),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (hasClip) "Changer Clip" else "Lier Clip MP4", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (hasClip) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                onRemoveVideoClip(episode.id, scene.sceneNumber)
                                promptDialogScene = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonDilemma)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Retirer le Clip Vidéo (Retour à l'image)")
                        }
                    }
                }
            }
        }
    }
}
