package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.EpisodeEntity
import com.example.ui.StudioUiState
import com.example.ui.components.EpisodeCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.LingalaGreen
import com.example.ui.theme.TerracottaSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioHomeScreen(
    episodes: List<EpisodeEntity>,
    totalEpisodesCount: Int,
    uiState: StudioUiState,
    onSelectArc: (Int?) -> Unit,
    onSelectStatus: (String?) -> Unit,
    onSearchChange: (String) -> Unit,
    onPlayReel: (EpisodeEntity) -> Unit,
    onEditEpisode: (EpisodeEntity) -> Unit,
    onCreateNextEpisode: () -> Unit,
    onGenerateNextBatch: () -> Unit,
    onGenerateAllTo150: () -> Unit,
    onToggleFavorite: (EpisodeEntity) -> Unit,
    onUpdateStatus: (EpisodeEntity, String) -> Unit,
    onCopyScript: (EpisodeEntity) -> Unit,
    onCopyAiPrompt: (EpisodeEntity) -> Unit,
    onExportEpisode: (EpisodeEntity) -> Unit,
    onDeleteEpisode: (EpisodeEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val readyCount = episodes.count { it.status == "SCENARIO_PRET" }
    val shootingCount = episodes.count { it.status == "EN_TOURNAGE" || it.status == "MONTE" }
    val publishedCount = episodes.count { it.status == "PUBLIE" }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1422))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_drama),
                            contentDescription = "Bannière Le Prix de la Foi",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color.Black.copy(alpha = 0.5f),
                                            Color.Black.copy(alpha = 0.9f)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = GoldPrimary
                            ) {
                                Text(
                                    text = "KUMBA CAST • 150 ÉPISODES VERTICAUX",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E1408)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "LE PRIX DE LA FOI",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Drame chrétien africain • TikTok & Reels 9:16 (45-90s) • FR & Lingala",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Production Pipeline Stats Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF18121E))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Objectif Série : 150 Épisodes",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                            Text(
                                text = "$totalEpisodesCount / 150",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (totalEpisodesCount / 150f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = GoldPrimary,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatPill(count = readyCount, label = "Scénarios Prêts", color = Color(0xFF3498DB))
                            StatPill(count = shootingCount, label = "En Tournage/Audio", color = TerracottaSecondary)
                            StatPill(count = publishedCount, label = "Publiés TikTok", color = LingalaGreen)
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("search_field"),
                    placeholder = { Text("Rechercher épisode, réplique, thème, verset...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = GoldPrimary
                        )
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotBlank()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Effacer")
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color(0xFF3E3544)
                    ),
                    singleLine = true
                )
            }

            // Arc Filter Chips Row
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Filtrer par Arc Narratif :",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = uiState.selectedArc == null,
                                onClick = { onSelectArc(null) },
                                label = { Text("Tous les Arcs (1-150)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary,
                                    selectedLabelColor = Color(0xFF1E1408)
                                )
                            )
                        }
                        listOf(
                            1 to "Arc 1 : Faim & Épreuve (1-30)",
                            2 to "Arc 2 : Tentation (31-65)",
                            3 to "Arc 3 : Mensonge (66-100)",
                            4 to "Arc 4 : Chute & Désert (101-130)",
                            5 to "Arc 5 : Gloire & Pardon (131-150)"
                        ).forEach { (arcNum, arcLabel) ->
                            item {
                                FilterChip(
                                    selected = uiState.selectedArc == arcNum,
                                    onClick = { onSelectArc(if (uiState.selectedArc == arcNum) null else arcNum) },
                                    label = { Text(arcLabel) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = GoldPrimary,
                                        selectedLabelColor = Color(0xFF1E1408)
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Status Filter Chips Row
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = uiState.selectedStatus == null,
                            onClick = { onSelectStatus(null) },
                            label = { Text("Tous les Statuts") }
                        )
                    }
                    listOf(
                        "SCENARIO_PRET" to "Scénarios Prêts",
                        "EN_TOURNAGE" to "En Tournage",
                        "MONTE" to "Montés",
                        "PUBLIE" to "Publiés TikTok",
                        "BROUILLON" to "Brouillons"
                    ).forEach { (code, label) ->
                        item {
                            FilterChip(
                                selected = uiState.selectedStatus == code,
                                onClick = { onSelectStatus(if (uiState.selectedStatus == code) null else code) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            // Section Title & Generation Actions
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Épisodes Disponibles (${episodes.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Button(
                            onClick = onCreateNextEpisode,
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1408)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("create_next_episode_header_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Épisode ${totalEpisodesCount + 1}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (totalEpisodesCount < 150) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onGenerateNextBatch,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_generate_batch_10"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("+ 10 Épisodes", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }

                            Button(
                                onClick = onGenerateAllTo150,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_generate_all_150"),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color(0xFF1E1408)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Générer les 150 (5 Arcs)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Episode Cards
            if (episodes.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF16111C)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Aucun épisode ne correspond à ces critères.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    onSelectArc(null)
                                    onSelectStatus(null)
                                    onSearchChange("")
                                }
                            ) {
                                Text("Réinitialiser les filtres")
                            }
                        }
                    }
                }
            } else {
                items(episodes, key = { it.id }) { episode ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        EpisodeCard(
                            episode = episode,
                            onPlayReel = { onPlayReel(episode) },
                            onEdit = { onEditEpisode(episode) },
                            onToggleFavorite = { onToggleFavorite(episode) },
                            onUpdateStatus = { newStatus -> onUpdateStatus(episode, newStatus) },
                            onCopyScript = { onCopyScript(episode) },
                            onCopyAiPrompt = { onCopyAiPrompt(episode) },
                            onExportMp4 = { onExportEpisode(episode) },
                            onDelete = { onDeleteEpisode(episode) }
                        )
                    }
                }
            }
        }

        // Floating Action Button to quickly add next episode
        FloatingActionButton(
            onClick = onCreateNextEpisode,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("fab_create_episode"),
            containerColor = GoldPrimary,
            contentColor = Color(0xFF1E1408)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter Épisode")
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Nouvel Épisode",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun StatPill(
    count: Int,
    label: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$count",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp
            )
        }
    }
}
