package com.example.data.repository

import com.example.data.local.EpisodeDao
import com.example.data.model.EpisodeEntity
import com.example.data.model.ProductionData
import kotlinx.coroutines.flow.Flow

class EpisodeRepository(private val episodeDao: EpisodeDao) {

    val allEpisodes: Flow<List<EpisodeEntity>> = episodeDao.getAllEpisodes()
    val favoriteEpisodes: Flow<List<EpisodeEntity>> = episodeDao.getFavoriteEpisodes()

    fun getEpisodeById(id: Long): Flow<EpisodeEntity?> = episodeDao.getEpisodeById(id)

    fun getEpisodesByArc(arcNumber: Int): Flow<List<EpisodeEntity>> =
        episodeDao.getEpisodesByArc(arcNumber)

    suspend fun getCount(): Int = episodeDao.getEpisodesCount()

    suspend fun saveEpisode(episode: EpisodeEntity): Long {
        return if (episode.id == 0L) {
            episodeDao.insertEpisode(episode)
        } else {
            episodeDao.updateEpisode(episode)
            episode.id
        }
    }

    suspend fun deleteEpisode(episode: EpisodeEntity) {
        episodeDao.deleteEpisode(episode)
    }

    suspend fun toggleFavorite(id: Long, currentFav: Boolean) {
        episodeDao.updateFavorite(id, !currentFav)
    }

    suspend fun updateStatus(id: Long, newStatus: String) {
        episodeDao.updateStatus(id, newStatus)
    }

    suspend fun updateViews(id: Long, views: Long) {
        episodeDao.updateViews(id, views)
    }

    suspend fun ensureInitialEpisodesLoaded() {
        val initialEpisodes = ProductionData.getInitialEpisodes()
        for (ep in initialEpisodes) {
            val existing = episodeDao.getEpisodeByNumber(ep.episodeNumber)
            if (existing == null) {
                episodeDao.insertEpisode(ep.toEntity())
            }
        }
    }

    suspend fun createNextEpisodeSlot(): EpisodeEntity {
        val maxNumber = episodeDao.getMaxEpisodeNumber() ?: 0
        val nextNumber = (maxNumber + 1).coerceAtMost(150)
        val newEpisode = ProductionData.generateEpisodeSlot(nextNumber).toEntity()
        val insertedId = episodeDao.insertEpisode(newEpisode)
        return newEpisode.copy(id = insertedId)
    }

    suspend fun generateEpisodesUpTo(targetCount: Int = 150): Int {
        val currentMax = episodeDao.getMaxEpisodeNumber() ?: 0
        if (currentMax >= targetCount) return 0
        val newEpisodes = ((currentMax + 1)..targetCount).map { num ->
            ProductionData.generateEpisodeSlot(num).toEntity()
        }
        episodeDao.insertEpisodes(newEpisodes)
        return newEpisodes.size
    }
}
