package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.EpisodeEntity
import com.example.data.model.ProductionData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [EpisodeEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun episodeDao(): EpisodeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "le_prix_de_la_foi.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate with initial episodes and slots
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getInstance(context).episodeDao()
                            val initial = ProductionData.getInitialEpisodes().map { it.toEntity() }
                            dao.insertEpisodes(initial)

                            // Pre-generate slots 11 to 30 so users have immediate access to initial arc episodes
                            val slots = (11..30).map { num ->
                                ProductionData.generateEpisodeSlot(num).toEntity()
                            }
                            dao.insertEpisodes(slots)
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
