package com.example.data.model

data class CharacterModel(
    val id: String,
    val name: String,
    val role: String,
    val age: String,
    val archetype: String,
    val spiritualTrajectory: String,
    val physicalDescription: String,
    val recurringClothing: String,
    val aiPromptTag: String,
    val quoteFr: String,
    val quoteLn: String,
    val avatarColorHex: Long
)

object CharactersBible {
    val characters = listOf(
        CharacterModel(
            id = "samuel",
            name = "Samuel Mbuyi",
            role = "Protagoniste principal",
            age = "27 ans",
            archetype = "Le Chrétien à l'épreuve de la faim",
            spiritualTrajectory = "Chrétien fervent -> tentation financière sous le désespoir -> chute dans le mensonge -> repentance brisée et restauration glorieuse.",
            physicalDescription = "Jeune homme congolais athlétique et humble, teint ébène chaud naturel aux pores et reflets réalistes, cheveux courts soignés, regard sincère marqué par la faim et l'intercession.",
            recurringClothing = "Chemise en coton bleu délavée propre et bien repassée, pantalon sombre sobre, montre modeste.",
            aiPromptTag = "Cinematic 9:16 vertical film still, 27yo Congolese man Samuel, authentic natural rich dark ebony skin tone with realistic skin texture, short neat haircut, deep sincere emotional eyes, wearing modest worn blue cotton shirt. Authentic Kinshasa outdoor street, natural vegetation of mango and acacia trees with varied organic sap and olive greens, absolutely no neon green. Natural blue sky with soft realistic white and grey clouds, warm natural late afternoon sunlight with soft realistic shadows on red laterite soil, photorealistic 35mm film still, balanced natural contrast, no artificial filters",
            quoteFr = "Seigneur, si je perds mon intégrité pour manger aujourd'hui, que me restera-t-il demain ?",
            quoteLn = "Nkolo, soki nabungisi bosembo na ngai mpo na kolia lelo, nini ekotikala na ngai lobi ?",
            avatarColorHex = 0xFFF3B33D
        ),
        CharacterModel(
            id = "esther",
            name = "Esther Nkumu",
            role = "Fiancée & Conscience spirituelle",
            age = "25 ans",
            archetype = "La Voix de la Sagesse et de la Foi",
            spiritualTrajectory = "Femme de prière inébranlable. Elle refuse les raccourcis douteux et soutient Samuel par l'intercession, même quand tout semble perdu.",
            physicalDescription = "Jeune femme congolaise gracieuse, tresses fines africaines soignées vers l'arrière, peau naturelle et lumineuse, regard pénétrant et résolu plein de foi.",
            recurringClothing = "Robe en pagne wax africain moderne jaune safran et indigo avec motifs traditionnels authentiques.",
            aiPromptTag = "Cinematic 9:16 vertical film still, 25yo Congolese woman Esther, authentic natural glowing dark skin tone with realistic soft texture, neat African box braids, compassionate yet resolute gaze, wearing traditional tailored African wax fabric dress in soft saffron and indigo. Authentic Kinshasa setting, natural courtyard vegetation with varied natural greens, soft natural daylight with gentle diffuse shadows, realistic fabric folds, 35mm cinema lens portrait, natural color grading, no oversaturation",
            quoteFr = "La bénédiction de l'Éternel enrichit, et Il ne la fait suivre d'aucun chagrin. N'achète pas la gloire au diable, Samuel !",
            quoteLn = "Lipamboli ya Yawe epesaka bomengo, mpe ebakisaka mawa te. Kosomba nkembo epai ya satana te, Samuel !",
            avatarColorHex = 0xFFE07A4F
        ),
        CharacterModel(
            id = "bokolo",
            name = "Directeur Patrick Bokolo",
            role = "Antagoniste / Tentateur",
            age = "48 ans",
            archetype = "L'Oligarque corrupteur",
            spiritualTrajectory = "Cynique, obsédé par le pouvoir et l'argent. Voit la foi comme une faiblesse des pauvres et teste l'intégrité de Samuel comme un jeu.",
            physicalDescription = "Homme mûr congolais imposant de 48 ans, barbe poivre et sel taillée avec précision, regard calculateur froid et sourire hautain.",
            recurringClothing = "Costume trois pièces sur mesure en laine sombre de coupe italienne, montre en métal doré, cravate sombre.",
            aiPromptTag = "Cinematic 9:16 vertical film still, 48yo wealthy Congolese executive Patrick Bokolo, natural deep skin tone with realistic mature facial lines, impeccably groomed salt-and-pepper beard, cold calculating expression, wearing elegant tailored dark charcoal business suit. High-rise office in Kinshasa, large window revealing authentic cityscape under midday natural bright sunlight with realistic architectural glass reflections and subtle directional shadows, no artificial glowing effects, 35mm film still",
            quoteFr = "Dans cette ville, Samuel, les versets ne paient pas les factures de la morgue. Signe ce papier, et ta mère vivra.",
            quoteLn = "Na engumba oyo, Samuel, ba vɛrsɛ efutaka ba factures ya morgue te. Tia signature na papye oyo, mpe mama na yo akozala na bomoi.",
            avatarColorHex = 0xFFC74343
        ),
        CharacterModel(
            id = "denis",
            name = "Pasteur Denis",
            role = "Mentor Spirituel",
            age = "56 ans",
            archetype = "Le Berger intègre et patient",
            spiritualTrajectory = "Sentinelle de prière, refuse la théologie de la prospérité trompeuse, enseigne la persévérance et accueille le fils prodigue.",
            physicalDescription = "Homme mûr de 56 ans, cheveux grisonnants, visage ridé par l'expérience et la bonté chrétienne, Bible aux tranches patinées.",
            recurringClothing = "Chemise blanche en coton simple ou veste en lin beige naturel.",
            aiPromptTag = "Cinematic 9:16 vertical film still, 56yo respected African pastor Denis, natural dark skin with realistic wrinkles of wisdom and warmth, grey-flecked short hair, holding a worn black leather Bible, wearing a clean modest white cotton shirt. Humble wooden parish courtyard in Kinshasa, natural morning sunlight filtering softly through mango tree leaves with organic varied greens, realistic dust motes in gentle light beams, natural earth textures, authentic 35mm cinematography",
            quoteFr = "Mieux vaut peu avec la crainte de l'Éternel, qu'un grand trésor avec le trouble. Tiens bon dans le jeûne !",
            quoteLn = "Eza malamu moke na botosi ya Yawe, koleka bomengo monene elongo na mitungisi. Tika te kokangama !",
            avatarColorHex = 0xFF2E7D32
        ),
        CharacterModel(
            id = "marie",
            name = "Maman Marie",
            role = "Mère de Samuel",
            age = "53 ans",
            archetype = "La Mère pieuse et souffrante",
            spiritualTrajectory = "Malade sur son lit d'hôpital, elle préfère mourir dans la foi que de voir son fils voler ou se compromettre pour elle.",
            physicalDescription = "Femme mûre de 53 ans amaigrie par la maladie mais d'une dignité royale, foulard africain noué sur la tête, regard apaisé.",
            recurringClothing = "Foulard traditionnel en wax et chemisier de maison en coton doux.",
            aiPromptTag = "Cinematic 9:16 vertical film still, 53yo Congolese mother Maman Marie resting on hospital bed, natural warm ebony skin tone with realistic fragile skin texture, tied traditional headscarf, peaceful spiritual expression of endurance, holding her son's hand. Clean modest clinic room, soft natural morning diffuse light through curtained window, realistic fabric folds, no exaggerated glow, authentic African drama still",
            quoteFr = "Mon fils, je ne t'ai pas élevé pour que tu vendes ton âme pour mon cercueil. Marche droit avec Dieu.",
            quoteLn = "Mwana na ngai, nabokoli yo te mpo otekisa molimo na yo mpo na sanduku na ngai. Tambola sembo elongo na Nzambe.",
            avatarColorHex = 0xFF8E44AD
        ),
        CharacterModel(
            id = "junior",
            name = "Junior (L'Ami d'enfance)",
            role = "Miroir de la compromission",
            age = "28 ans",
            archetype = "Le Débrouillard sans scrupule",
            spiritualTrajectory = "A choisi les combines de la rue et les fétiches pour réussir vite ; sert d'avertissement vivant à Samuel.",
            physicalDescription = "Jeune homme nerveux de 28 ans, regard inquiet et fuyant, peau sombre naturelle, attitude sur la défensive.",
            recurringClothing = "Blouson streetwear coloré mais usé, chaîne métallique argentée simple.",
            aiPromptTag = "Cinematic 9:16 vertical film still, 28yo Congolese young man Junior, natural dark complexion with realistic sheen of nervous sweat, anxious tense facial expression, wearing worn urban streetwear jacket. Busy Kinshasa street market, authentic crowded background with natural earth ground, natural afternoon diffuse daylight with realistic ambient reflections, 35mm documentary realism",
            quoteFr = "Samuel, la prière sans connexion c'est zéro. Réveille-toi, nous sommes à Kinshasa !",
            quoteLn = "Samuel, losambo kozanga connexion eza zero. Lamuka, tozali na Kinshasa !",
            avatarColorHex = 0xFF3498DB
        )
    )
}
