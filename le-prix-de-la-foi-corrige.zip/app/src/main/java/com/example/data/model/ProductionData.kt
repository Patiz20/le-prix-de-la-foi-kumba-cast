package com.example.data.model

data class StoryArc(
    val arcNumber: Int,
    val titleFr: String,
    val titleLn: String,
    val episodesRange: String,
    val mainTheme: String,
    val synopsis: String,
    val keyVerse: String
)

data class ProductionTip(
    val id: String,
    val phaseNumber: Int,
    val title: String,
    val subtitle: String,
    val costTag: String, // "0 USD - 100% Gratuit"
    val description: String,
    val steps: List<String>,
    val freeToolRecommendations: List<String>
)

object ProductionData {

    val arcs = listOf(
        StoryArc(
            arcNumber = 1,
            titleFr = "Arc 1 : L'Épreuve du Chômage et la Faim",
            titleLn = "Etando 1 : Meko ya Kozanga Mosala mpe Nzala",
            episodesRange = "Épisodes 1 à 30",
            mainTheme = "Foi & Intégrité",
            synopsis = "Samuel fait face à 3 ans de chômage, aux moqueries du quartier, et à la maladie foudroyante de Maman Marie. Il refuse les pots-de-vin jusqu'à ce que l'hôpital menace de débrancher sa mère.",
            keyVerse = "Proverbes 10:22 - C'est la bénédiction de l'Éternel qui enrichit, et Il ne la fait suivre d'aucun chagrin."
        ),
        StoryArc(
            arcNumber = 2,
            titleFr = "Arc 2 : La Tentation du Succès Facile",
            titleLn = "Etando 2 : Meko ya Bomengo ya Pamba",
            episodesRange = "Épisodes 31 à 65",
            mainTheme = "Ambition & Compromis",
            synopsis = "Embauché par Bokolo sous condition de falsifier un bilan d'appel d'offres. Samuel cède pour sauver sa mère, reçoit sa première grosse prime, mais commence à mentir à Esther et à l'église.",
            keyVerse = "Matthieu 16:26 - Que servirait-il à un homme de gagner tout le monde, s'il perdait son âme ?"
        ),
        StoryArc(
            arcNumber = 3,
            titleFr = "Arc 3 : L'Engrenage du Mensonge et de la Trahison",
            titleLn = "Etando 3 : Mokili ya Lokuta mpe Kofungola Ndako",
            episodesRange = "Épisodes 66 à 100",
            mainTheme = "Mensonge & Culpabilité",
            synopsis = "L'argent coule à flots mais la paix intérieure disparaît. Samuel évite Esther, trahit la confiance du Pasteur Denis, et découvre que Bokolo trempe dans un réseau mafieux dangereux.",
            keyVerse = "Proverbes 19:9 - Le faux témoin ne restera point impuni, et celui qui dit des mensonges périra."
        ),
        StoryArc(
            arcNumber = 4,
            titleFr = "Arc 4 : La Chute, le Chantage et le Désert",
            titleLn = "Etando 4 : Kokweya mpe Esobe ya Mawa",
            episodesRange = "Épisodes 101 à 130",
            mainTheme = "Épreuve & Repentance",
            synopsis = "Bokolo fait porter le chapeau à Samuel devant la justice. Comptes gelés, abandonné par ses faux amis de fête. Seule Esther vient le voir au parloir pour lui rappeler la grâce de la Croix.",
            keyVerse = "Psaumes 51:17 - Les sacrifices qui sont agréables à Dieu, c'est un esprit brisé."
        ),
        StoryArc(
            arcNumber = 5,
            titleFr = "Arc 5 : La Rédemption, le Pardon et la Gloire de Dieu",
            titleLn = "Etando 5 : Kobikisama, Bolimbisi mpe Nkembo ya Nzambe",
            episodesRange = "Épisodes 131 à 150",
            mainTheme = "Pardon & Réconciliation",
            synopsis = "Samuel avoue toute la vérité devant le tribunal et pardonne à Bokolo. Miraculeusement innocenté des crimes de sang, il bâtit une entreprise éthique et épouse Esther dans la joie et la gloire de Dieu.",
            keyVerse = "Romains 8:28 - Toutes choses concourent au bien de ceux qui aiment Dieu."
        )
    )

    val productionGuide = listOf(
        ProductionTip(
            id = "hook_script",
            phaseNumber = 1,
            title = "Le Format 45-90s & La Règle d'Or des 3s (Hook)",
            subtitle = "Stopper le scroll sur TikTok et Instagram Reels",
            costTag = "0 USD - 100% Gratuit",
            description = "Sur TikTok et Reels, 80% des spectateurs quittent la vidéo si les 3 premières secondes manquent d'impact émotionnel ou de dilemme moral direct.",
            steps = listOf(
                "Commencer directement par la phrase choc ou le conflit (ex: 'Si je ne donne pas 500$, ma mère meurt ce soir.')",
                "Ne jamais mettre de générique de début, aller droit au drame.",
                "Structure type 60 secondes : 0-3s Accroche -> 4-20s Dilemme -> 21-45s Confrontation/Climax -> 46-55s Verset d'impact -> 56-60s Call To Action KUMBA CAST.",
                "Alterner les répliques françaises courtes et les expressions percutantes en Lingala pour un ancrage culturel puissant."
            ),
            freeToolRecommendations = listOf("Éditeur de script intégré dans cette application", "Chronomètre vocal intégré")
        ),
        ProductionTip(
            id = "free_ai_images",
            phaseNumber = 2,
            title = "Génération d'Images Réalistes Cohérentes à 0$",
            subtitle = "Créer les acteurs et décors sans payer d'abonnement",
            costTag = "0 USD - Quotas gratuits quotidiens",
            description = "Guide de réalisme visuel africain : obtenir des images naturelles, lumineuses et cinématographiques fidèles aux paysages et à la vie quotidienne d'Afrique avec les outils gratuits (Bing Image Creator / Leonardo AI).",
            steps = listOf(
                "1. Arbres & Végétation : Spécifier des verts naturels et variés (vert olive, sève, forêt tropicale). Proscrire tout vert fluorescent, néon ou sursaturé.",
                "2. Ciel & Nuages : Décrire un ciel bleu naturel avec des nuages blancs ou légèrement gris doux bien intégrés à l'horizon.",
                "3. Soleil & Lumière : Ajuster à l'heure de la scène (matin doux, midi clair et franc, après-midi doré, coucher de soleil chaleureux, pluie/nuages diffus). Ne pas forcer un soleil visible.",
                "4. Couleurs & Paysages : Préserver les teintes réelles de la terre rouge (latérite), briques, maçonneries et pagnes sans filtre excessif ni contraste outrancier.",
                "5. Personnages : Préserver la texture de peau naturelle ébène/noire avec micro-détails, traits authentiques et cohérence vestimentaire stricte.",
                "6. Réalisme Cinématographique : Cadrage 35mm, ombres douces et cohérentes, scènes de jour lumineuses et scènes de nuit nocturnes authentiques.",
                "7. Format Vertical 9:16 : Cadrage plein écran direct prêt pour l'intégration mobile et l'exportation vidéo MP4."
            ),
            freeToolRecommendations = listOf("Microsoft Copilot / Bing Image Creator (gratuit avec compte Microsoft)", "Leonardo.ai (150 crédits quotidiens gratuits)", "SeaArt.ai (génération gratuite quotidienne)")
        ),
        ProductionTip(
            id = "capcut_animation",
            phaseNumber = 3,
            title = "Animation 2.5D & Mouvements Caméra dans CapCut",
            subtitle = "Donner vie aux images fixes sans générateur vidéo payant",
            costTag = "0 USD - Application mobile gratuite",
            description = "Pas besoin de payer Runway ou Kling AI. Les meilleurs créateurs TikTok utilisent la technique du zoom dynamique sur image fixe.",
            steps = listOf(
                "Importer l'image 9:16 dans CapCut mobile gratuit.",
                "Appliquer l'effet 'Style' -> '3D Zoom Pro' ou zoom dynamique gratuit.",
                "Alternative manuelle : Poser deux Keyframes (images clés) : Début à 100% d'échelle, fin à 115% pour simuler un travelling lent vers l'avant.",
                "Pour les moments de choc ou colère : ajouter une transition 'Secousse' (Camera Shake) légère de 0.2s."
            ),
            freeToolRecommendations = listOf("CapCut Mobile (gratuit)", "VN Video Editor (gratuit sans filigrane)", "Canva Mobile (version gratuite)")
        ),
        ProductionTip(
            id = "voice_recording",
            phaseNumber = 4,
            title = "Enregistrement Voix Off & Doublage Émotionnel",
            subtitle = "Un son de qualité cinéma avec votre simple smartphone",
            costTag = "0 USD - Outils du quotidien",
            description = "La voix porte 70% de l'émotion dans un drame chrétien. Une voix bien enregistrée transforme de simples images en chef-d'œuvre poignant.",
            steps = listOf(
                "Enregistrer sous une couverture ou dans une penderie de vêtements pour supprimer tout écho de la pièce.",
                "Tenir le microphone du téléphone à 15 cm de la bouche, légèrement de biais pour éviter les 'P' et 'B' explosifs.",
                "Mettre du cœur et de l'âme : faire des pauses dramatiques de 1 seconde avant les répliques clés.",
                "Utiliser l'outil gratuit 'Adobe Podcast Voice Enhance' (gratuit en ligne) pour transformer un enregistrement de téléphone en son de studio radio."
            ),
            freeToolRecommendations = listOf("Adobe Podcast Audio Enhance (gratuit sur le web)", "Dolby On (application mobile gratuite)", "Dictaphone Android natif")
        ),
        ProductionTip(
            id = "gospel_music",
            phaseNumber = 5,
            title = "Musiques & Bruitages Libres de Droits",
            subtitle = "Ambiance spirituelle poignante sans risque de droits d'auteur",
            costTag = "0 USD - 100% Légal",
            description = "Les musiques gospel au piano et cordes amplifient les larmes et la prière sans violer les droits de monétisation de TikTok et Instagram.",
            steps = listOf(
                "Télécharger des pistes d'ambiance 'Cinematic Emotional Piano' et 'African Strings' libres de droits.",
                "Bruitages essentiels : battement de cœur sourd pour la tentation, vent lourd pour la solitude, éclat de verre ou tonnerre pour la trahison.",
                "Règle de mixage : La musique ne doit jamais dépasser -18dB sous la voix narrative.",
                "Couper brutalement la musique 2 secondes avant le verset final pour créer un impact saisissant."
            ),
            freeToolRecommendations = listOf("Bibliothèque audio YouTube Studio (gratuite et libre de droits)", "Pixabay Music (gospel / cinematic libre de droits)", "Freesound.org (bruitages gratuits)")
        ),
        ProductionTip(
            id = "social_growth",
            phaseNumber = 6,
            title = "Stratégie de Diffusion TikTok & Reels (KUMBA CAST)",
            subtitle = "Fidéliser la communauté chrétienne et toucher des millions d'âmes",
            costTag = "0 USD - Portée organique",
            description = "Comment structurer la publication des 150 épisodes pour créer une habitude quotidienne chez les spectateurs.",
            steps = listOf(
                "Rythme de publication : 1 épisode par jour à heure fixe (18h00 ou 20h00, heure de Kinshasa / Paris).",
                "Numéroter clairement la vidéo sur la miniature : 'Épisode 1/150 - Le Prix de la Foi'.",
                "Créer une Playlist TikTok officielle intitulée 'LE PRIX DE LA FOI - SÉRIE COMPLÈTE'.",
                "Hashtags optimisés : #LePrixDeLaFoi #KumbaCast #DrameChretien #CinemaAfricain #ChretienTikTok #Kinshasa #TemoignageChretien #FoiEtEpreuve",
                "Épingler un commentaire engageant : 'Et toi, aurais-tu cédé à la place de Samuel ? Dis-le nous en commentaire !'"
            ),
            freeToolRecommendations = listOf("TikTok Creator Center", "Instagram Creator Studio", "CapCut Auto-Captions (pour les sous-titres animés)")
        )
    )

    fun getInitialEpisodes(): List<InitialEpisodeData> {
        return listOf(
            InitialEpisodeData(
                episodeNumber = 1,
                arcNumber = 1,
                titleFr = "La Lettre de l'Hôpital",
                titleLn = "Mokanda ya Lopitalo",
                synopsis = "Samuel rentre chez lui après son 42ème refus d'embauche. À la maison, le médecin lui annonce que si les 800$ d'opération pour Maman Marie ne sont pas payés avant 48h, tout est fini.",
                durationSeconds = 60,
                status = "SCENARIO_PRET",
                primaryTheme = "Pauvreté",
                bibleVerseRef = "Psaumes 34:19",
                bibleVerseFr = "Le malheur atteint souvent le juste, mais l'Éternel l'en délivre toujours.",
                bibleVerseLn = "Mawa ezwaka moto ya sembo mbala mingi, kasi Yawe abikisaka ye na nyonso.",
                hookFr = "800 dollars en 48 heures, ou ma mère meurt. Et mon compte affiche zéro franc.",
                hookLn = "Dolari nkama mwambe na ngonga tuku minei na mwambe, to mama na ngai akokufa. Nzoka kiti na ngai eza zero.",
                ctaFr = "Sauvera-t-il sa mère sans voler ? Abonne-toi pour l'épisode 2 de KUMBA CAST !",
                soundMood = "Piano lent et battement de cœur angoissé",
                visualPrompt = "Cinematic 9:16 vertical film still, 27yo Congolese man Samuel holding a hospital bill with trembling hands, genuine tears in eyes, modest room in Kinshasa, warm late afternoon natural sunlight filtering through dusty window, realistic natural skin texture, modest worn blue shirt, natural muted interior colors, photorealistic 35mm cinema lens, realistic shadows, no artificial glow",
                montageGuide = "Keyframe 1: Plan moyen sur la lettre (0-4s) -> Zoom progressif sur le visage décomposé de Samuel (5-18s) -> Flash blanc avec bruit de moniteur cardiaque.",
                scenes = listOf(
                    SceneData(1, 0, 8, "Samuel", "Gros plan visage", "Zoom avant lent", "Samuel fixe la facture médicale, la gorge nouée par le choc.", "800 dollars... C'est ce que vaut la vie de ma mère selon ce papier. Et moi, je n'ai même pas de quoi payer le taxi.", "Dolari nkama mwambe... Yango nde motuya ya bomoi ya mama na mokanda oyo. Nzoka ngai ata mbongo ya taxi nazangi.", "Désespoir contenu", "Bruit sourd d'un moniteur cardiaque"),
                    SceneData(2, 9, 22, "Médecin Kasongo", "Contre-plongée froide", "Panoramique lent", "Le médecin range son stéthoscope avec indifférence.", "Je suis désolé jeune homme. La clinique privée n'est pas une église. Pas d'argent avant vendredi 16h, on débranche les appareils.", "Nayoki mawa mwana na ngai. Lopitalo oyo eza ndako ya Nzambe te. Soki mbongo ezali te yambo ya lomingo, tokolongola bamasini.", "Froideur bureaucratique", "Nappe de cordes mélancoliques"),
                    SceneData(3, 23, 37, "Maman Marie", "Gros plan main tremblante", "Lumière douce", "Maman Marie ouvre péniblement les yeux et serre les doigts de son fils.", "Samuel, mwana na ngai... Ne vends pas ton âme au diable pour me sauver. Dieu pourvoira, ou Il me rappellera à Lui dans Sa paix.", "Samuel, mwana na ngai... Kotekisa molimo na yo epai ya satana te mpo na ngai. Nzambe akosala, to akobenga ngai na kimia na Ye.", "Dignité spirituelle et paix", "Chant gospel a cappella lointain"),
                    SceneData(4, 38, 49, "Samuel", "Gros plan yeux embués", "Tremblement dramatique", "Samuel tombe à genoux près du lit, déchiré entre la piété et l'angoisse.", "Seigneur Dieu ! J'ai jeûné, j'ai refusé la corruption et le vol. Pourquoi permets-Tu que le diable ricane devant notre détresse ?", "Nkolo Nzambe ! Nakili bilei, naboyaki kaniaka mpe boyibi. Mpo na nini otiki satana asekela biso na mawa oyo ?", "Cris d'angoisse et de foi", "Crescendo de violon dramatique"),
                    SceneData(5, 50, 60, "Narrateur KUMBA CAST", "Texte stylisé TikTok", "Fond flou cinématique", "Apparition du verset de réconfort et du logo KUMBA CAST.", "Le malheur atteint souvent le juste, mais l'Éternel l'en délivre toujours. Psaumes 34:19. Samuel va-t-il céder ? Abonne-toi pour l'épisode 2 !", "Mawa ezwaka moto ya sembo mbala mingi, kasi Yawe abikisaka ye na nyonso. Nzembo 34:19. Samuel akondima komekama ? Tika kombo na yo mpo na eteni 2 !", "Solennel et apaisant", "Accord de piano pur")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 2,
                arcNumber = 1,
                titleFr = "L'Offre Empoisonnée de Bokolo",
                titleLn = "Likabo ya Ngɛngɛ ya Bokolo",
                synopsis = "Désespéré dans les rues de Kinshasa, Samuel croise Junior qui l'emmène dans le bureau vitré du richissime Directeur Patrick Bokolo. Une mallette de billets est posée sur la table.",
                durationSeconds = 65,
                status = "SCENARIO_PRET",
                primaryTheme = "Tentation",
                bibleVerseRef = "Proverbes 1:10",
                bibleVerseFr = "Mon fils, si des pécheurs veulent te séduire, ne te laisse pas entraîner.",
                bibleVerseLn = "Mwana na ngai, soki basali masumu balingi kokosa yo, kondima te.",
                hookFr = "Il a ouvert la mallette : 5 000 dollars en liquide. Mais le prix à payer me glaçait le sang.",
                hookLn = "Afungoli valize : dolari nkoto mitano ya cash. Kasi motuya nasengelaki kofuta ebandi kobangisa ngai.",
                ctaFr = "Va-t-il signer le faux contrat ? La suite demain sur KUMBA CAST !",
                soundMood = "Basse sourde de suspense et tintement métallique",
                visualPrompt = "Cinematic 9:16 vertical film still, modern glass corporate office in Kinshasa, 48yo wealthy Congolese businessman Patrick Bokolo in tailored charcoal suit smiling maliciously, briefcase with US dollars on mahogany desk. Midday natural bright daylight streaming through window, view of Kinshasa skyline under natural blue sky with soft white clouds, natural realistic skin tones, subtle architectural shadows, photorealistic 35mm cinematography",
                montageGuide = "Effet 3D Zoom sur la mallette de billets -> Contre-plongée sur Bokolo avec ombre tranchée -> Travelling sur Samuel qui hésite.",
                scenes = listOf(
                    SceneData(1, 0, 10, "Directeur Bokolo", "Plan poitrine dominant", "Zoom avant lent", "Bokolo fait claquer les serrures de la mallette pleine de billets de 100$.", "Samuel, ton ami Junior m'a parlé de ta situation. Ici, il y a 5 000 dollars. Assez pour opérer ta mère et t'acheter une voiture.", "Samuel, moninga na yo Junior ayebisi ngai likambo na yo. Awa ezali dolari nkoto mitano. Ekoki mpo na mama mpe mpo na motuka.", "Charisme séducteur", "Clic sec des serrures en métal"),
                    SceneData(2, 11, 28, "Samuel", "Gros plan hésitant", "Panoramique gauche", "Samuel regarde l'argent, puis la croix en bois à son cou.", "Qu'attendez-vous de moi en échange, Monsieur le Directeur ? Rien n'est gratuit à Kinshasa.", "Nini ozali kosenga ngai mpo na mbongo oyo, Patron ? Eloko ya ofele ezalaka te na Kinshasa.", "Méfiance et attirance", "Battement de cœur sourd"),
                    SceneData(3, 29, 50, "Directeur Bokolo", "Gros plan regard prédateur", "Travelling avant", "Bokolo pose un contrat de travaux publics frauduleux.", "Une simple signature. Tu approuves ce matériel périmé pour l'école publique. Personne ne saura. Sauve ta mère, mon garçon.", "Signature moko pamba. Ondima biloko oyo mpo na kelasi ya leta. Moto moko te akoyeba. Bikisa mama na yo, mwana.", "Pression psychologique glaciale", "Note de violoncelle stridente"),
                    SceneData(4, 51, 65, "Narrateur KUMBA CAST", "Texte stylisé", "Slow motion", "Samuel tient le stylo, la main tremblante. La tentation est à son comble.", "Mon fils, si des pécheurs veulent te séduire, ne te laisse pas entraîner. Proverbes 1:10.", "Mwana na ngai, soki basali masumu balingi kokosa yo, kondima te. Masese 1:10.", "Suspense insoutenable", "Clap dramatique final")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 3,
                arcNumber = 1,
                titleFr = "La Prière dans la Nuit",
                titleLn = "Losambo na Butu",
                synopsis = "Avant de donner sa réponse, Samuel retrouve sa fiancée Esther sous un lampadaire défaillant. Esther sent le piège spirituel et refuse qu'il sacrifie sa conscience pour de l'argent sale.",
                durationSeconds = 60,
                status = "SCENARIO_PRET",
                primaryTheme = "Foi",
                bibleVerseRef = "Matthieu 6:33",
                bibleVerseFr = "Cherchez premièrement le royaume et la justice de Dieu ; et toutes ces choses vous seront données par-dessus.",
                bibleVerseLn = "Bozwa liboso bokonzi ya Nzambe mpe bosembo na ye ; mpe biloko oyo nyonso ekobakisama na yo.",
                hookFr = "Elle a regardé mes mains et m'a dit : 'Si tu signes avec le diable, je ne t'épouserai jamais.'",
                hookLn = "Atali maboko na ngai mpe alobi : 'Soki otii signature na satana, nakobala yo ata mokolo moko te.'",
                ctaFr = "L'amour et la foi peuvent-ils résister à la faim ? Suivez KUMBA CAST !",
                soundMood = "Guitare acoustique mélancolique et chant gospel lointain",
                visualPrompt = "Cinematic 9:16 vertical film still, young Congolese couple Samuel and Esther standing outdoors in Kinshasa at night. Esther wearing traditional wax dress in soft saffron and indigo holding Samuel's face with deep love and tears. Authentic African urban night with gentle warm sodium street lamp glow, natural deep dark nocturnal sky, realistic skin highlights, natural shadows, no oversaturation, 35mm film still",
                montageGuide = "Plans alternés champ/contre-champ rapides -> Gros plan sur les larmes d'Esther -> Transition fondue au noir sur la nuit étoilée.",
                scenes = listOf(
                    SceneData(1, 0, 12, "Samuel", "Plan rapproché", "Zoom avant", "Samuel montre l'avance en billets avec honte.", "Esther, si je ne signe pas, maman n'aura pas son traitement. Dieu comprendra, Il sait que c'est une urgence !", "Esther, soki natie signature te, mama akozwa lisungi te. Nzambe akososola, ayebi ete eza likambo ya nokinoki !", "Détresse et justification", "Guitare acoustique intime"),
                    SceneData(2, 13, 30, "Esther", "Gros plan visage digne", "Lumière dorée douce", "Esther prend les mains de Samuel et les serre fort.", "Dieu n'a jamais besoin du vol pour accomplir un miracle, Samuel ! Tu veux sauver son corps en damnant ton âme ?", "Nzambe azali na mposa ya boyibi te mpo na kosala likamwisi, Samuel ! Olingi kobikisa nzoto na ye na kobungisa molimo na yo ?", "Autorité spirituelle et amour", "Nappe de cordes céleste"),
                    SceneData(3, 31, 48, "Samuel & Esther", "Plan à deux en prière", "Travelling circulaire lent", "Ils tombent ensemble à genoux dans la poussière.", "Père, garde nos cœurs purs dans la fournaise. Donne-nous le pain de ce jour, mais éloigne-nous du compromis.", "Tata, batela mitema na biso na moto. Pesa biso mapa ya lelo, kasi longola biso na kosala mabe.", "Ferveur et larmes", "Chœur gospel angélique"),
                    SceneData(4, 49, 60, "Narrateur KUMBA CAST", "Typographie dorée", "Éclat lumineux", "Apparition du verset de foi", "Cherchez premièrement le royaume et la justice de Dieu... Matthieu 6:33.", "Bozwa liboso bokonzi ya Nzambe mpe bosembo na ye... Matayo 6:33.", "Paix triomphante", "Sonorité de cloche pure")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 4,
                arcNumber = 1,
                titleFr = "Le Miracle Inattendu",
                titleLn = "Likamwisi ya Kokamwa",
                synopsis = "Ayant refusé l'offre de Bokolo, Samuel s'attend au pire à l'hôpital. Mais un ancien patient dont Samuel avait prié pour la guérison autrefois a réglé l'intégralité de la facture.",
                durationSeconds = 65,
                status = "SCENARIO_PRET",
                primaryTheme = "Espérance",
                bibleVerseRef = "Psaumes 37:5",
                bibleVerseFr = "Recommande ton sort à l'Éternel, mets en lui ta confiance, et il agira.",
                bibleVerseLn = "Pesa nzela na yo na maboko ya Yawe, tia motema na ye, mpe ye akosala.",
                hookFr = "Je venais pour annoncer la mort de ma mère. Le médecin m'a tendu le reçu : 'Payé en totalité'.",
                hookLn = "Nayei koyebisa liwa ya mama na ngai. Monganga apesi ngai mokanda : 'Efutama mobimba'.",
                ctaFr = "Dieu n'abandonne jamais les siens. Partage cette vidéo pour fortifier quelqu'un !",
                soundMood = "Piano majestueux et cordes triomphantes",
                visualPrompt = "Cinematic 9:16 vertical film still, modest hospital room in Kinshasa bathed in soft morning natural sunlight. 53yo ailing Congolese mother with headscarf smiling radiantly and holding her son's hand in joyful tears. Soft diffuse light, natural skin tones, outside window reveals lush mango trees with natural sap and olive greens under clear morning sky, authentic emotional cinema portrait, 35mm lens",
                montageGuide = "Entrée rapide caméra subjective dans le couloir de l'hôpital -> Arrêt brutal devant le médecin -> Explosion de lumière et sourire.",
                scenes = listOf(
                    SceneData(1, 0, 10, "Samuel", "Caméra épaule nerveuse", "Travelling avant", "Samuel arrive en sueur à l'accueil de la clinique.", "Docteur, je vous en supplie, ne débranchez rien ! Accordez-moi encore vingt-quatre heures !", "Monganga, nabondeli yo, kokata eloko moko te ! Pesa ngai lisusu ngonga tuku mibale na minei !", "Angoisse extrême", "Respiration haletante"),
                    SceneData(2, 11, 28, "Médecin", "Plan moyen souriant", "Zoom lent", "Le médecin tend une enveloppe tamponnée 'ACQUITTÉ'.", "Calmez-vous, jeune homme. Un homme d'affaires anonyme est venu ce matin à 7 heures. Toute l'intervention est payée.", "Kitisa motema, elenge. Moto moko ya mombongo ayei na tongo ya lelo na ngonga ya nsambo. Lifuta nyonso esili kosalema.", "Soulagement inouï", "Cordes lumineuses ascendante"),
                    SceneData(3, 29, 50, "Maman Marie", "Gros plan radieux", "Lumière douce", "Maman Marie prend le visage de Samuel dans ses mains faibles.", "Je te l'avais dit, Samuel... Nzambe azali Nzambe ! La foi qui attend Dieu n'est jamais couverte de honte.", "Nayebisaki yo, Samuel... Nzambe azali Nzambe ! Kondima oyo ezelaka Nzambe ezwaka soni ata mokolo moko te.", "Gratitude émue", "Hymne de louange gospel doux"),
                    SceneData(4, 51, 65, "Narrateur KUMBA CAST", "Texte or sur fond noir", "Zoom lent", "Apparition du verset de délivrance", "Recommande ton sort à l'Éternel, mets en lui ta confiance, et il agira. Psaumes 37:5.", "Pesa nzela na yo na maboko ya Yawe, tia motema na ye, mpe ye akosala. Nzembo 37:5.", "Gloire et foi", "Accord final triomphal")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 5,
                arcNumber = 1,
                titleFr = "La Rancune de Bokolo",
                titleLn = "Kanda ya Bokolo",
                synopsis = "Vexé qu'un petit jeune sans le sou lui ait tenu tête et refusé son argent, le Directeur Bokolo décide de détruire la réputation de Samuel dans tout le secteur d'affaires.",
                durationSeconds = 60,
                status = "SCENARIO_PRET",
                primaryTheme = "Trahison",
                bibleVerseRef = "Ésaïe 54:17",
                bibleVerseFr = "Toute arme forgée contre toi sera sans effet ; et toute langue qui s'élèvera en justice contre toi, tu la condamneras.",
                bibleVerseLn = "Ebundeli nyonso oyo basaleli yo ekolonga te ; mpe lolemo nyonso oyo ekotombokela yo, okozwa yango na libunga.",
                hookFr = "Bokolo a tapé du poing sur la table : 'Personne ne me refuse son âme à Kinshasa. Je vais le briser.'",
                hookLn = "Bokolo abeti mesa na kanda : 'Moto moko te aboyaka ngai na Kinshasa. Nakopasola ye.'",
                ctaFr = "Comment Samuel survivra-t-il aux loups ? Abonne-toi à KUMBA CAST !",
                soundMood = "Tambours africains sourds et tension montante",
                visualPrompt = "Cinematic 9:16 vertical film still, furious executive Patrick Bokolo slamming fist on mahogany desk in top-floor office. Realistic nocturnal atmosphere, natural dark night sky over Kinshasa with distant realistic lightning flash through glass, natural rain streaks, realistic skin tones, dramatic yet authentic indoor shadows, 35mm film still",
                montageGuide = "Keyframe percutant sur le poing de Bokolo -> Flash d'éclair par la baie vitrée -> Musique percussive lourde.",
                scenes = listOf(
                    SceneData(1, 0, 15, "Directeur Bokolo", "Gros plan regard furieux", "Contre-plongée", "Bokolo s'adresse à Junior, terrifié dans un coin du bureau.", "Il a osé me rendre mon chèque en me disant que Dieu pourvoirait ? Pour qui se prend ce mendiant de quartier ?", "Amoni mpiko ya kozongisa chèque na ngai na koloba Nzambe akosala ? Ye nani, moto oyo ya bozangi na kartye ?", "Orgueil blessé et rage", "Tambour sourd et basse lourde"),
                    SceneData(2, 16, 32, "Junior", "Plan rapproché tremblant", "Travelling arrière", "Junior bégaye, conscient de l'engrenage mortel.", "Patron, Samuel est têtu depuis l'enfance quand il s'agit de son église... Laissez-le partir, il n'a rien.", "Patron, Samuel azali motó makasi banda bomwana soki eza likambo ya ndako Nzambe... Tika ye akende.", "Peur et compromission", "Tintement métallique angoissant"),
                    SceneData(3, 33, 48, "Directeur Bokolo", "Gros plan sourire machiavélique", "Zoom avant", "Bokolo allume un cigare et compose un numéro sur son smartphone doré.", "Passe le mot à tous les directeurs de la ville : Samuel Mbuyi est blacklisté. Pas un seul emploi, même pour balayer le sol !", "Yebisa bakonzi nyonso ya engumba : Samuel Mbuyi azwa mosala te. Ata mpo na kokomba lopango te !", "Vengeance froide", "Gong dramatique"),
                    SceneData(4, 49, 60, "Narrateur KUMBA CAST", "Texte lumineux", "Lumière divine", "Apparition du verset de protection", "Toute arme forgée contre toi sera sans effet. Ésaïe 54:17. L'Éternel est notre bouclier.", "Ebundeli nyonso oyo basaleli yo ekolonga te. Yisaya 54:17.", "Résilience et foi", "Percussion finale nette")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 6,
                arcNumber = 1,
                titleFr = "La Porte Fermée et la Voix de Dieu",
                titleLn = "Ekuke Ekangami mpe Mongongo ya Nzambe",
                synopsis = "Blacklisté partout, Samuel est renvoyé de trois entretiens d'affilée sans explication. Mais au fond de son abattement, le Pasteur Denis lui révèle une opportunité d'entreprise éthique que personne n'attendait.",
                durationSeconds = 60,
                status = "SCENARIO_PRET",
                primaryTheme = "Espérance",
                bibleVerseRef = "Apocalypse 3:8",
                bibleVerseFr = "J'ai mis devant toi une porte ouverte, que personne ne peut fermer, parce que tu as peu de puissance et que tu as gardé ma parole.",
                bibleVerseLn = "Natieli yo ekuke ya kofungwama, oyo moto moko te akoki kokanga, mpo ozali na nguya moke kasi obatelaki liloba na ngai.",
                hookFr = "Toutes les entreprises m'ont fermé la porte au nez. Mais Dieu n'a pas besoin de leur clé.",
                hookLn = "Bakompanyi nyonso bakangeli ngai bikuke. Kasi Nzambe azali na mposa ya fungola na bango te.",
                ctaFr = "Le début de la vraie revanche de la foi ! Rejoins l'aventure KUMBA CAST !",
                soundMood = "Guitare acoustique inspirante et envolée de piano",
                visualPrompt = "Cinematic 9:16 vertical film still, 56yo venerable African pastor Denis placing an encouraging hand on young Samuel's shoulder on wooden church steps. Natural varied green acacia and palm foliage in the churchyard without neon saturation, natural blue sky with soft light-grey clouds, warm natural afternoon sunlight casting gentle shadows on red laterite soil, authentic modest clothing, photorealistic 35mm cinema lens, realistic textures",
                montageGuide = "Travelling arrière depuis la porte d'un bureau moderne fermée brutalement -> Transition fluide vers la porte ouverte de l'église baignée de soleil.",
                scenes = listOf(
                    SceneData(1, 0, 14, "Samuel", "Gros plan désemparé", "Zoom avant", "Samuel s'assied sur les marches de l'église, dossiers sous le bras.", "Ils ne regardent même plus mon CV. Dès qu'ils voient mon nom, ils détournent le regard. Bokolo m'a détruit.", "Batalaka lisusu ata CV na ngai te. Soki bamoni kombo na ngai, babalukaka. Bokolo abebisi ngai.", "Fatigue et sentiment d'injustice", "Vent doux et silence mélancolique"),
                    SceneData(2, 15, 32, "Pasteur Denis", "Plan moyen paternel", "Lumière douce", "Le Pasteur s'assied à côté de lui avec un sourire calme.", "Quand les hommes ferment les portes de la servitude, Dieu ouvre souvent la porte de ta propre destinée, Samuel.", "Ntango bato bakangi bikuke ya bopika, mbala mingi Nzambe afungolaka ekuke ya likabo na yo moko, Samuel.", "Sagesse et réconfort", "Notes de guitare inspirantes"),
                    SceneData(3, 33, 48, "Pasteur Denis", "Gros plan regard confiant", "Travelling avant", "Le pasteur lui tend les clés d'un atelier abandonné de la paroisse.", "Utilise ton diplôme en informatique pour former la jeunesse d'ici. Nous allons commencer avec trois ordinateurs et la prière.", "Salela boyebi na yo ya informatique mpo na koteya bilenge ya awa. Tokobanda na ordinatɛrɛ misato mpe losambo.", "Vision et espoir", "Montée d'orchestre lumineux"),
                    SceneData(4, 49, 60, "Narrateur KUMBA CAST", "Texte or étincelant", "Lumière dorée", "Apparition du verset de promesse", "J'ai mis devant toi une porte ouverte que personne ne peut fermer. Apocalypse 3:8.", "Natieli yo ekuke ya kofungwama, oyo moto moko te akoki kokanga. Emoniseli 3:8.", "Victoire spirituelle", "Accord majestueux")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 7,
                arcNumber = 1,
                titleFr = "Le Premier Atelier de l'Espérance",
                titleLn = "Atelier ya Yambo ya Elikya",
                synopsis = "Samuel et Esther nettoient l'ancien atelier paroissial avec 3 vieux ordinateurs. Malgré les intimidations nocturnes de Bokolo dont la vitre a été brisée, trois jeunes délinquants du quartier frappent à la porte pour apprendre et changer de vie.",
                durationSeconds = 65,
                status = "SCENARIO_PRET",
                primaryTheme = "Espérance",
                bibleVerseRef = "Zacharie 4:10",
                bibleVerseFr = "Car ceux qui méprisaient le jour des faibles commencements se réjouiront.",
                bibleVerseLn = "Mpo baoyo batiolaki mokolo ya ebandeli ya moke bakosepela.",
                hookFr = "Ils ont brisé notre vitre à deux heures du matin. À six heures, trois jeunes faisaient la queue pour apprendre.",
                hookLn = "Babukaki talatala na biso na butu. Na tongo, bilenge misato bazalaki kowela kokota.",
                ctaFr = "Les faibles commencements deviennent de grands témoignages ! Abonne-toi à KUMBA CAST.",
                soundMood = "Bruit de verre balayé et guitare acoustique chaleureuse et pleine d'espoir",
                visualPrompt = "Cinematic 9:16 vertical film still, modest church computer workshop in Kinshasa being cleaned by Samuel and Esther. Soft natural morning daylight streaming through window frame, vintage computers on wooden tables. Courtyard visible outside with lush natural tropical foliage in varied organic greens under pale blue morning sky, natural earth tones, realistic 35mm cinematography",
                montageGuide = "Plan serré sur le verre brisé balayé par Esther -> Travelling avant sur Samuel qui allume le premier écran -> Sourire des trois jeunes sur le pas de la porte.",
                scenes = listOf(
                    SceneData(1, 0, 15, "Samuel & Esther", "Plan moyen débris de verre", "Panoramique lent", "Esther ramasse les éclats avec calme tandis que Samuel serre les poings.", "Samuel : Bokolo a envoyé ses voyous. Ils veulent nous briser avant même le premier cours.\nEsther : Le diable attaque toujours ce qui menace son règne. Balayons ce verre et allumons les écrans.", "Samuel : Bokolo atindi bilenge na ye ya mabe. Balingi kobangisa biso.\nEsther : Satana abundaki kaka oyo ezali kokweisa bokonzi na ye. To balola talatala oyo mpe to pelisa bamasini.", "Résolution spirituelle", "Bruit de balai et souffle de vent"),
                    SceneData(2, 16, 32, "Samuel", "Gros plan écran CRT", "Zoom avant", "Le ventilateur d'un vieil ordinateur démarre avec un bip net.", "Ça tourne ! Trois machines offertes par la paroisse. C'est petit, mais c'est le début d'un empire pour la gloire du Seigneur.", "Ebandi kosala ! Ordinatɛrɛ misato kaka, kasi eza ebandeli ya likambo monene mpo na nkembo ya Nkolo.", "Foi et émerveillement", "Bip électronique et accord de guitare"),
                    SceneData(3, 33, 48, "Kader (Jeune du quartier)", "Plan américain sur le seuil", "Lumière rasante", "Trois adolescents hésitent sur le pas de la porte, impressionnés.", "Frère Samuel... On nous a dit que tu apprenais l'informatique sans demander d'argent d'avance ? On veut quitter la rue et apprendre à coder.", "Frère Samuel... Bayebisi biso oteyaka informatique ofele ? Tolingi kotika nzela ya mabe mpe koyekola.", "Timidité et soif d'avenir", "Nappe de cordes douce"),
                    SceneData(4, 49, 65, "Narrateur KUMBA CAST", "Texte or sur fond ambré", "Lueur divine", "Apparition du verset d'encouragement", "Car ceux qui méprisaient le jour des faibles commencements se réjouiront. Zacharie 4:10. La foi ne recule jamais !", "Mpo baoyo batiolaki mokolo ya ebandeli ya moke bakosepela. Zakali 4:10.", "Paix rayonnante", "Accord de piano pur")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 8,
                arcNumber = 1,
                titleFr = "Le Piège du Faux Client",
                titleLn = "Motambo ya Kiliya ya Lokuta",
                synopsis = "Un homme d'affaires élégant mais mystérieux arrive dans l'atelier et pose une liasse de 3 000$ pour cloner frauduleusement la base de données d'une coopérative chrétienne. Samuel démasque l'émissaire de Bokolo et le renvoie avec fermeté.",
                durationSeconds = 60,
                status = "SCENARIO_PRET",
                primaryTheme = "Tentation",
                bibleVerseRef = "Psaumes 15:1-2",
                bibleVerseFr = "Éternel ! qui séjournera dans ta tente ? Celui qui marche dans l'intégrité, qui pratique la justice.",
                bibleVerseLn = "Yawe ! nani akovanda na hema na yo ? Moto oyo atambolaka na bosembo, oyo asalaka boyengebene.",
                hookFr = "3 000 dollars en liquide posés sur mon clavier. Tout ce qu'il demandait, c'était de pirater un frère en Christ.",
                hookLn = "Dolari nkoto misato etiami likolo ya clavier na ngai. Asengaki kaka nayiba ndeko na Klisto.",
                ctaFr = "La fidélité dans l'ombre apporte la bénédiction dans la lumière. Suis KUMBA CAST !",
                soundMood = "Piano sourd et pulsation angoissante de basse",
                visualPrompt = "Cinematic 9:16 vertical film still, shady wealthy Congolese client leaning over wooden desk, waving an envelope of cash towards principled young Samuel who firmly gestures refusal. Midday clear daylight through open workshop door, authentic Kinshasa street visible with natural red laterite soil, modest brick buildings and natural green trees, realistic natural skin tones, authentic 35mm film still",
                montageGuide = "Gros plan sur l'enveloppe de dollars claquant sur la table -> Champ/contre-champ tendu -> La main de Samuel repousse calmement l'enveloppe.",
                scenes = listOf(
                    SceneData(1, 0, 14, "Faux Client", "Plan rapproché dominant", "Zoom avant", "L'homme pose une enveloppe débordant de billets de 100$.", "Je te donne 3 000 dollars cash. Tu copies juste la base de données de la coopérative agricole chrétienne. Dix minutes, et personne ne saura.", "Napesi yo dolari nkoto misato cash. Yiba kaka base de données ya bandeko ya coopérative. Miniti zomi kaka, moto moko akoyeba te.", "Arrogance et corruption", "Clac sec de l'enveloppe"),
                    SceneData(2, 15, 30, "Samuel", "Gros plan regard droit", "Lumière contrastée", "Samuel regarde l'argent sans trembler, puis fixe l'homme droit dans les yeux.", "Monsieur, vous vous êtes trompé de porte. Ici, nous apprenons aux enfants à créer de la valeur, pas à piller nos frères d'église.", "Monsieur, obungi nzela. Awa toteyaka bilenge kotonga mboka, mpo na koyiba bandeko te.", "Intégrité inébranlable", "Basse sourde tendue"),
                    SceneData(3, 31, 48, "Faux Client & Samuel", "Plan à deux en tension", "Travelling lent", "L'homme ricane nerveusement avant de ranger ses billets.", "Client : Tu es un idiot idéaliste, Samuel. Bokolo t'écrasera.\nSamuel : Mon Dieu nourrit les oiseaux du ciel. Reprenez votre argent sale et sortez de ce lieu saint.", "Client : Ozali zoba, Samuel. Bokolo akopasola yo.\nSamuel : Nzambe na ngai aleisaka bandeke ya likolo. Zwa mbongo na yo ya mabe mpe bima awa.", "Confrontation morale", "Montée de violon dramatique"),
                    SceneData(4, 49, 60, "Narrateur KUMBA CAST", "Texte or étincelant", "Lumière divine", "Apparition du verset d'intégrité", "Qui séjournera dans ta tente ? Celui qui marche dans l'intégrité. Psaumes 15:1-2. La victoire appartient aux cœurs purs.", "Nani akovanda na hema na yo ? Moto oyo atambolaka na bosembo. Nzembo 15:1-2.", "Victoire spirituelle", "Gong majestueux")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 9,
                arcNumber = 1,
                titleFr = "La Trahison de Junior",
                titleLn = "Bokabi mabe ya Junior",
                synopsis = "Junior, étranglé par une dette de jeu auprès de Bokolo, s'introduit de nuit dans l'atelier paroissial sous un orage violent pour voler les ordinateurs et le disque dur. Samuel le surprend sous la pluie.",
                durationSeconds = 70,
                status = "SCENARIO_PRET",
                primaryTheme = "Trahison",
                bibleVerseRef = "Psaumes 41:9",
                bibleVerseFr = "Celui-là même avec qui j'étais en paix, qui avait ma confiance et qui mangeait mon pain, a levé le talon contre moi.",
                bibleVerseLn = "Moto oyo tozalaki na kimia elongo, oyo natiaki motema mpe aliaki mapa na ngai, atomboli litindi na ngai.",
                hookFr = "On a partagé le même pain pendant dix ans. Cette nuit, il fuyait sous la pluie avec notre seul outil de travail.",
                hookLn = "Toliaki mapa moko mbula zomi. Na butu oyo, azalaki kokima na mbula na bamasini na ngai.",
                ctaFr = "La trahison d'un frère brise le cœur. Samuel va-t-il se venger ? Découvre l'épisode 10 sur KUMBA CAST !",
                soundMood = "Orage tropical violent, tonnerre lointain et violons tragiques",
                visualPrompt = "Cinematic 9:16 vertical film still, heavy tropical downpour in Kinshasa unpaved street at night. Samuel catching his childhood friend Junior carrying a stolen computer monitor under the rain, profound heartbreak and shock on their faces. Authentic wet red laterite mud with natural reflections, deep natural night sky with soft diffuse street ambient, natural skin texture glistening with raindrops, 35mm realism",
                montageGuide = "Ralenti sous la pluie diluvienne -> Éclair illuminant le visage masqué de Junior -> Choc dans les yeux de Samuel.",
                scenes = listOf(
                    SceneData(1, 0, 16, "Junior", "Plan serré nocturne", "Caméra épaule nerveuse", "Junior débranche les câbles dans la pénombre, ruisselant de sueur et d'angoisse.", "Pardonne-moi Samuel... Bokolo a promis d'effacer ma dette si je lui livre vos fichiers ce soir. Je n'avais pas le choix...", "Limbisa ngai Samuel... Bokolo alobaki akolongola niongo na ngai soki namemi badosiye na yo. Nazalaki na choix te...", "Culpabilité et terreur", "Bruit de pluie torrentielle et tonnerre"),
                    SceneData(2, 17, 35, "Samuel & Junior", "Plan moyen sous la pluie", "Zoom avant lent", "Samuel arrive sous un parapluie déchiré et barre la ruelle obscure.", "Junior ? C'est toi ? Toi que j'ai nourri quand tu n'avais rien ? Tu voles l'espoir des enfants de notre église ?", "Junior ? Yo nde ? Yo moto nalisaki ntango ozangaki ? Ozali koyiba elikya ya bana ya kartye ?", "Déchirement fraternel", "Crescendo de cordes tragiques"),
                    SceneData(3, 36, 54, "Junior", "Gros plan ruisselant de pluie", "Éclair lumineux", "Junior s'effondre contre un mur de briques en tenant l'ordinateur trempé.", "Ils allaient me tuer, Samuel ! Bokolo tient toute la ville ! Tu crois que tes prières vont arrêter ses balles ?", "Balingaki koboma ngai, Samuel ! Bokolo azali na nguya na engumba mobimba ! Okanisi losambo na yo ekopekisa masasi ?", "Désespoir hystérique", "Basse lourde et vent d'orage"),
                    SceneData(4, 55, 70, "Narrateur KUMBA CAST", "Texte or sur fond de pluie", "Ralenti cinématique", "Apparition du verset de douleur", "Celui-là même avec qui j'étais en paix a levé le talon contre moi. Psaumes 41:9. La trahison du frère est la plus grande épreuve.", "Moto oyo tozalaki na kimia atomboli litindi na ngai. Nzembo 41:9.", "Gravité solennelle", "Coup de tonnerre final")
                )
            ),
            InitialEpisodeData(
                episodeNumber = 10,
                arcNumber = 1,
                titleFr = "Le Pardon Qui Brise les Chaînes",
                titleLn = "Bolimbisi oyo Ekangolaka Maboko",
                synopsis = "Alors que la foule du quartier veut livrer Junior à la police et le battre, Samuel s'interpose, le couvre de sa veste et lui offre le pardon au nom de Jésus. Bouleversé par cet amour surnaturel, Junior confesse tout le complot de Bokolo.",
                durationSeconds = 75,
                status = "SCENARIO_PRET",
                primaryTheme = "Pardon",
                bibleVerseRef = "Romains 12:21",
                bibleVerseFr = "Ne te laisse pas vaincre par le mal, mais surmonte le mal par le bien.",
                bibleVerseLn = "Kondima kolongama na mabe te, kasi longa mabe na kosala malamu.",
                hookFr = "La foule criait : 'Livrez-le à la police !' J'ai posé ma main sur lui et j'ai dit : 'Je te pardonne mon frère.'",
                hookLn = "Bato bazalaki koganga : 'Bóbimisa ye epai ya polisi !' Natiaki loboko na mapeka na ye mpe nalobi : 'Nalimbisi yo ndeko na ngai.'",
                ctaFr = "Le pardon chrétien brise les pièges du diable. Partage ce témoignage puissant avec KUMBA CAST !",
                soundMood = "Chœur gospel a cappella émouvant puis envolée orchestrale céleste",
                visualPrompt = "Cinematic 9:16 vertical film still, young Congolese man Samuel embracing his weeping friend Junior in a red laterite neighborhood street surrounded by solemn neighbors. Soft natural golden morning sunrise light breaking through light mist, natural green acacia trees in background, authentic African crowd in modest real clothing, genuine expressions of mercy and emotional release, photorealistic 35mm cinema lens",
                montageGuide = "Foule en furie -> Samuel s'interpose bras ouverts -> Ralenti sur l'étreinte en larmes -> Lever de soleil doré éblouissant.",
                scenes = listOf(
                    SceneData(1, 0, 16, "Foule & Samuel", "Plan large tendu", "Travelling rapide", "Des voisins armés de bâtons entourent Junior à genoux dans la poussière.", "Voisins : Qu'on appelle les patrouilles ! C'est un traître !\nSamuel : Rangez vos bâtons ! Dans cette paroisse, nous n'enseignons pas la vengeance des hommes, mais la miséricorde du Christ.", "Bato : Bobenga bapolisi ! Azali moyibi !\nSamuel : Bobwaka banzete na bino ! Awa toteyaka kofuta mabe na mabe te, kasi mawa ya Klisto.", "Tension extrême puis apaisement", "Cris de foule qui s'éteignent doucement"),
                    SceneData(2, 17, 36, "Samuel & Junior", "Plan poitrine intime", "Zoom avant doux", "Samuel retire sa propre veste et la pose sur les épaules tremblantes de Junior.", "Junior, regarde-moi. Jésus a payé nos dettes à la Croix. Je ne te jetterai pas en prison. Tu es mon ami, et je te pardonne.", "Junior, tala ngai. Yesu afutaki baniongo na biso na Ekulusu. Nakomema yo na boloko te. Ozali moninga na ngai, mpe nalimbisi yo.", "Amour inconditionnel chrétien", "Guitare acoustique lumineuse"),
                    SceneData(3, 37, 55, "Junior", "Gros plan visage baigné de larmes", "Lumière dorée du matin", "Junior s'effondre dans les bras de Samuel en sanglotant de repentance.", "Samuel... Personne ne m'a jamais aimé comme ça... Bokolo m'a donné un enregistreur pour voler vos logiciels. Prends-le ! Je vais tout te révéler !", "Samuel... Ata moto moko alingaki ngai boye te... Bokolo apesaki ngai apareye mpo na koyiba biloko na yo. Zwa yango ! Nakoyebisa yo sekre nyonso !", "Repentance sincère et délivrance", "Chœur gospel congolais puissant"),
                    SceneData(4, 56, 65, "Esther & Pasteur Denis", "Plan moyen sourires émus", "Lumière douce", "Esther et le Pasteur joignent leurs mains dans la prière.", "Pasteur Denis : La haine engendre la haine, mais l'amour de Dieu a vaincu l'abîme. Junior est né de nouveau ce matin.", "Kanda ebotaka kanda, kasi bolingo ya Nzambe elongi libulu. Junior abotami ya sika na tongo ya lelo.", "Sainte joie", "Accords d'orgue céleste"),
                    SceneData(5, 66, 75, "Narrateur KUMBA CAST", "Typographie dorée éclatante", "Effet de particules lumineuses", "Fin victorieuse de l'Arc 1", "Ne te laisse pas vaincre par le mal, mais surmonte le mal par le bien. Romains 12:21. Fin de l'Arc 1. Rendez-vous dans l'Arc 2 : La Tentation du Succès !", "Kondima kolongama na mabe te, kasi longa mabe na kosala malamu. Baroma 12:21.", "Triomphe divin", "Sonnerie de cloches célestes")
                )
            )
        )
    }

    fun generateEpisodeSlot(number: Int): InitialEpisodeData {
        val arcNum = when (number) {
            in 1..30 -> 1
            in 31..65 -> 2
            in 66..100 -> 3
            in 101..130 -> 4
            else -> 5
        }
        val theme = when (arcNum) {
            1 -> if (number % 2 == 0) "Pauvreté" else "Foi"
            2 -> if (number % 2 == 0) "Tentation" else "Ambition"
            3 -> if (number % 2 == 0) "Mensonge" else "Trahison"
            4 -> if (number % 2 == 0) "Pardon" else "Épreuve"
            else -> if (number % 2 == 0) "Réconciliation" else "Espérance"
        }
        val arcTitle = arcs.firstOrNull { it.arcNumber == arcNum }?.titleFr ?: "Arc $arcNum"

        val timeOfDay = when (number % 5) {
            0 -> "soft natural morning light with light mist, clear sky"
            1 -> "crisp bright midday natural light, consistent realistic shadows, natural blue sky with soft white clouds"
            2 -> "warm natural late afternoon sunlight, golden hues on red laterite soil"
            3 -> "natural sunset golden hour, warm atmospheric glow without oversaturation"
            else -> "authentic tropical night, deep dark nocturnal sky, gentle warm street lamp glow, natural shadows"
        }

        val foliageDescription = "lush natural African vegetation with varied organic sap, olive and forest greens of acacia and mango trees, strictly no fluorescent greens"

        return InitialEpisodeData(
            episodeNumber = number,
            arcNumber = arcNum,
            titleFr = "Épisode $number : Le Choix de l'Intégrité",
            titleLn = "Eteni $number : Kopona ya Bosembo",
            synopsis = "Progression dramatique dans $arcTitle. Samuel est confronté aux répercussions directes de ses choix spirituels dans les rues de Kinshasa.",
            durationSeconds = 60,
            status = "BROUILLON",
            primaryTheme = theme,
            bibleVerseRef = "Proverbes 10:9",
            bibleVerseFr = "Celui qui marche dans l'intégrité marche avec assurance, mais celui qui prend des voies tortueuses sera découvert.",
            bibleVerseLn = "Moto oyo atambolaka na bosembo atambolaka na motema kokita, kasi moto ya banzela ya mabe akomonana.",
            hookFr = "À Kinshasa, chaque seconde d'hésitation peut te coûter ton salut ou ta vie.",
            hookLn = "Na Kinshasa, segonde moko ya kobanga ekoki kobungisa yo molimo to bomoi.",
            ctaFr = "Rejoins l'armée de la foi ! Abonne-toi à KUMBA CAST.",
            soundMood = "Tension dramatique africaine et cordes gospel",
            visualPrompt = "Cinematic 9:16 vertical film still, authentic African drama scene in Kinshasa. Character in intense moral contemplation, realistic natural dark skin tones with genuine skin texture. Surroundings featuring $foliageDescription, authentic laterite earth and modest buildings under $timeOfDay. 35mm cinema lens, realistic balanced contrast, natural colors, no artificial filters",
            montageGuide = "Zoom progressif 3D dans CapCut -> Coupure franche sur réplique choc -> Verset biblique d'impact final.",
            scenes = listOf(
                SceneData(1, 0, 15, "Samuel", "Gros plan", "Zoom lent", "Face à une nouvelle décision difficile dans l'épreuve.", "Je refuse de céder au compromis, même si tout le monde le fait.", "Naboyi kosala mabe, ata soki bato nyonso bazali kosala yango.", "Résolution ferme", "Basse sourde"),
                SceneData(2, 16, 35, "Esther", "Plan moyen", "Panoramique", "Esther rappelle les promesses divines.", "Notre Dieu est fidèle. Il ne délaisse jamais le juste.", "Nzambe na biso azali sembo. Akotika moto ya bosembo ata mokolo moko te.", "Foi ardente", "Nappe lumineuse"),
                SceneData(3, 36, 50, "Directeur Bokolo", "Contre-plongée", "Travelling", "L'opposition tente un nouveau piège.", "Tu crois que ta foi va nourrir ta famille ?", "Okanisi kondima na yo ekolia bana ?", "Arrogance", "Effet dramatique"),
                SceneData(4, 51, 60, "Narrateur", "Texte plein écran", "Lumière dorée", "Apparition du verset final", "Celui qui marche dans l'intégrité marche avec assurance. Proverbes 10:9.", "Moto oyo atambolaka na bosembo atambolaka na motema kokita. Masese 10:9.", "Gloire", "Accord pur")
            )
        )
    }
}

data class InitialEpisodeData(
    val episodeNumber: Int,
    val arcNumber: Int,
    val titleFr: String,
    val titleLn: String,
    val synopsis: String,
    val durationSeconds: Int,
    val status: String,
    val primaryTheme: String,
    val bibleVerseRef: String,
    val bibleVerseFr: String,
    val bibleVerseLn: String,
    val hookFr: String,
    val hookLn: String,
    val ctaFr: String,
    val soundMood: String,
    val visualPrompt: String,
    val montageGuide: String,
    val scenes: List<SceneData>
) {
    fun toEntity(): EpisodeEntity {
        val sceneModels = scenes.map {
            SceneModel(
                sceneNumber = it.sceneNumber,
                timeStartSec = it.timeStartSec,
                timeEndSec = it.timeEndSec,
                character = it.character,
                cameraShot = it.cameraShot,
                cameraMovement = it.cameraMovement,
                actionDescription = it.actionDescription,
                dialogueFr = it.dialogueFr,
                dialogueLn = it.dialogueLn,
                emotion = it.emotion,
                sfxAudio = it.sfxAudio
            )
        }
        return EpisodeEntity(
            episodeNumber = episodeNumber,
            arcNumber = arcNumber,
            titleFr = titleFr,
            titleLn = titleLn,
            synopsis = synopsis,
            durationSeconds = durationSeconds,
            status = status,
            primaryTheme = primaryTheme,
            bibleVerseRef = bibleVerseRef,
            bibleVerseFr = bibleVerseFr,
            bibleVerseLn = bibleVerseLn,
            hookFr = hookFr,
            hookLn = hookLn,
            ctaFr = ctaFr,
            visualPrompt = visualPrompt,
            montageGuide = montageGuide,
            scenesJson = SceneModel.serializeList(sceneModels),
            soundMood = soundMood
        )
    }
}

data class SceneData(
    val sceneNumber: Int,
    val timeStartSec: Int,
    val timeEndSec: Int,
    val character: String,
    val cameraShot: String,
    val cameraMovement: String,
    val actionDescription: String,
    val dialogueFr: String,
    val dialogueLn: String,
    val emotion: String,
    val sfxAudio: String
)
