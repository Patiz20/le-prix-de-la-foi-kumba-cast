package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EpisodeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EpisodeDao {
    @Query("SELECT * FROM episodes ORDER BY episodeNumber ASC")
    fun getAllEpisodes(): Flow<List<EpisodeEntity>>

    @Query("SELECT * FROM episodes WHERE id = :id")
    fun getEpisodeById(id: Long): Flow<EpisodeEntity?>

    @Query("SELECT * FROM episodes WHERE episodeNumber = :number LIMIT 1")
    suspend fun getEpisodeByNumber(number: Int): EpisodeEntity?

    @Query("SELECT * FROM episodes WHERE arcNumber = :arcNumber ORDER BY episodeNumber ASC")
    fun getEpisodesByArc(arcNumber: Int): Flow<List<EpisodeEntity>>

    @Query("SELECT * FROM episodes WHERE isFavorite = 1 ORDER BY episodeNumber ASC")
    fun getFavoriteEpisodes(): Flow<List<EpisodeEntity>>

    @Query("SELECT COUNT(*) FROM episodes")
    suspend fun getEpisodesCount(): Int

    @Query("SELECT MAX(episodeNumber) FROM episodes")
    suspend fun getMaxEpisodeNumber(): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisode(episode: EpisodeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisodes(episodes: List<EpisodeEntity>)

    @Update
    suspend fun updateEpisode(episode: EpisodeEntity)

    @Delete
    suspend fun deleteEpisode(episode: EpisodeEntity)

    @Query("UPDATE episodes SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFav: Boolean)

    @Query("UPDATE episodes SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE episodes SET actualViews = :views, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateViews(id: Long, views: Long, updatedAt: Long = System.currentTimeMillis())
}
