package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

data class SceneModel(
    val sceneNumber: Int,
    val timeStartSec: Int,
    val timeEndSec: Int,
    val character: String,
    val cameraShot: String,
    val cameraMovement: String,
    val actionDescription: String,
    val dialogueFr: String,
    val dialogueLn: String,
    val emotion: String,
    val sfxAudio: String,
    val videoUri: String? = null
) {
    val durationSec: Int get() = (timeEndSec - timeStartSec).coerceAtLeast(1)

    fun hasVideoClip(): Boolean = !videoUri.isNullOrBlank()

    fun generateAiVideoPrompt(episodeNumber: Int = 1, theme: String = "Foi et Épreuve"): String {
        val characterDesc = when {
            character.contains("Docteur", ignoreCase = true) || character.contains("Médecin", ignoreCase = true) || character.contains("Kasongo", ignoreCase = true) -> 
                "Doctor Kasongo, 45-year-old Congolese male physician in a hospital clinic in Kinshasa, wearing a clean white lab coat with stethoscope around neck, compassionate and focused expression, speaking clearly"
            character.contains("Marie", ignoreCase = true) || character.contains("Maman", ignoreCase = true) -> 
                "Maman Marie, 53-year-old ailing Congolese mother resting on a hospital bed in Kinshasa clinic, wearing light headscarf, weak but spiritually radiant, smiling with gratitude, realistic skin tones"
            character.contains("Samuel", ignoreCase = true) -> 
                "Samuel Mbuyi, 26-year-old Congolese young man in Kinshasa, dressed in modest casual shirt, intense expressive brown eyes, showing deep emotional struggle, authentic facial acting, speaking with passion"
            character.contains("Bokolo", ignoreCase = true) || character.contains("Directeur", ignoreCase = true) || character.contains("Patron", ignoreCase = true) -> 
                "Director Patrick Bokolo, 52-year-old wealthy corrupt Congolese executive in a tailored suit and gold watch, in high-rise Kinshasa office, authoritative, cynical smirk and imposing gestures"
            character.contains("Denis", ignoreCase = true) || character.contains("Pasteur", ignoreCase = true) -> 
                "Pastor Denis, 56-year-old venerable Congolese church pastor, humble dark suit, serene, wise and encouraging facial expression, placing hand on shoulder in prayer"
            character.contains("Esther", ignoreCase = true) -> 
                "Esther, 24-year-old devout Congolese young woman, wearing colorful modern African wax pagne, hands clasped in fervent prayer, tears of faith and radiant hope"
            character.contains("Junior", ignoreCase = true) -> 
                "Junior, 20-year-old Kinshasa street youth, streetwear t-shirt, tense nervous expression, fidgeting hands, authentic Matonge street background"
            else -> "$character, authentic Congolese actor in Kinshasa drama series 'Le Prix de la Foi', highly realistic emotional acting"
        }

        return """
            [KUMBA CAST AI VIDEO PROMPT - SCÈNE $sceneNumber | ÉPISODE $episodeNumber]
            FORMAT: 9:16 vertical video reel (1080x1920), cinematic 24fps drama, photorealistic African cinema, realistic skin texture.
            CHARACTER: $characterDesc.
            SETTING & LIGHTING: Authentic Kinshasa drama setting, natural daylight or warm interior lighting, shallow depth of field, 35mm film grain.
            CAMERA SHOT: $cameraShot, $cameraMovement, steady cinematic movement.
            ACTION & PERFORMANCE: $actionDescription. Natural head movement, realistic mouth speech movement synchronized with dialogue, expressive eyes and authentic gestures.
            DIALOGUE SPOKEN: "$dialogueFr"
            EMOTION: $emotion. Dramatic intensity, cinematic realism, no exaggerated expressions.
            FREE AI TOOLS: Kling AI (klingai.com) / Hailuo MiniMax (hailuoai.video) / Luma Dream Machine (lumalabs.ai).
            NEGATIVE PROMPT: anime, cartoon, 3d render, plastic doll, distorted fingers, watermark, blurry, low resolution, static photo.
        """.trimIndent()
    }

    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("sceneNumber", sceneNumber)
            put("timeStartSec", timeStartSec)
            put("timeEndSec", timeEndSec)
            put("character", character)
            put("cameraShot", cameraShot)
            put("cameraMovement", cameraMovement)
            put("actionDescription", actionDescription)
            put("dialogueFr", dialogueFr)
            put("dialogueLn", dialogueLn)
            put("emotion", emotion)
            put("sfxAudio", sfxAudio)
            if (videoUri != null) {
                put("videoUri", videoUri)
            }
        }
    }

    companion object {
        fun fromJson(json: JSONObject): SceneModel {
            return SceneModel(
                sceneNumber = json.optInt("sceneNumber", 1),
                timeStartSec = json.optInt("timeStartSec", 0),
                timeEndSec = json.optInt("timeEndSec", 10),
                character = json.optString("character", "Narrateur"),
                cameraShot = json.optString("cameraShot", "Gros Plan"),
                cameraMovement = json.optString("cameraMovement", "Zoom lent avant"),
                actionDescription = json.optString("actionDescription", ""),
                dialogueFr = json.optString("dialogueFr", ""),
                dialogueLn = json.optString("dialogueLn", ""),
                emotion = json.optString("emotion", "Intense"),
                sfxAudio = json.optString("sfxAudio", "Nappe dramatique"),
                videoUri = json.optString("videoUri", null).takeIf { !it.isNullOrBlank() }
            )
        }

        fun parseList(jsonString: String): List<SceneModel> {
            if (jsonString.isBlank()) return emptyList()
            return try {
                val array = JSONArray(jsonString)
                val list = mutableListOf<SceneModel>()
                for (i in 0 until array.length()) {
                    list.add(fromJson(array.getJSONObject(i)))
                }
                list
            } catch (e: Exception) {
                emptyList()
            }
        }

        fun serializeList(list: List<SceneModel>): String {
            val array = JSONArray()
            list.forEach { array.put(it.toJson()) }
            return array.toString()
        }
    }
}
