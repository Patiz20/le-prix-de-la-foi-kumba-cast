package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "episodes")
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val episodeNumber: Int,
    val arcNumber: Int,
    val titleFr: String,
    val titleLn: String,
    val synopsis: String,
    val durationSeconds: Int,
    val status: String, // BROUILLON, SCENARIO_PRET, EN_TOURNAGE, MONTE, PUBLIE
    val primaryTheme: String, // Foi, Pauvreté, Ambition, Tentation, Mensonge, Trahison, Pardon, Réconciliation, Espérance
    val bibleVerseRef: String,
    val bibleVerseFr: String,
    val bibleVerseLn: String,
    val hookFr: String,
    val hookLn: String,
    val ctaFr: String,
    val visualPrompt: String,
    val montageGuide: String,
    val scenesJson: String,
    val soundMood: String,
    val viewsTarget: Long = 10000,
    val actualViews: Long = 0,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
