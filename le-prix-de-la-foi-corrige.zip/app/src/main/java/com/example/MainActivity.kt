package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.EpisodeEntity
import com.example.data.model.SceneModel
import com.example.ui.MainViewModel
import com.example.ui.StudioTab
import com.example.ui.components.EpisodeEditorDialog
import com.example.ui.components.VideoExportModal
import com.example.ui.screens.CharactersScreen
import com.example.ui.screens.ProductionGuideScreen
import com.example.ui.screens.ReelPlayerScreen
import com.example.ui.screens.StudioHomeScreen
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.LePrixDeLaFoiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LePrixDeLaFoiTheme {
                LePrixDeLaFoiApp()
            }
        }
    }
}

@Composable
fun LePrixDeLaFoiApp(viewModel: MainViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val rawEpisodes by viewModel.rawEpisodes.collectAsState()
    val filteredEpisodes by viewModel.filteredEpisodes.collectAsState()

    // Handle Android system back gesture when not on main screen
    BackHandler(enabled = uiState.activeTab != StudioTab.EPISODES) {
        viewModel.selectTab(StudioTab.EPISODES)
    }

    val activeReelEpisode = viewModel.getActiveReelEpisode()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            // Hide bottom bar in Reel player if full immersion is desired or keep clean navigation
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar"),
                containerColor = Color(0xFF140F18),
                contentColor = GoldPrimary
            ) {
                NavigationBarItem(
                    selected = uiState.activeTab == StudioTab.EPISODES,
                    onClick = { viewModel.selectTab(StudioTab.EPISODES) },
                    icon = { Icon(Icons.Default.Movie, contentDescription = "Épisodes") },
                    label = { Text("Épisodes") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF1A1208),
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_episodes")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == StudioTab.REEL_PLAYER,
                    onClick = { viewModel.selectTab(StudioTab.REEL_PLAYER) },
                    icon = { Icon(Icons.Default.SmartDisplay, contentDescription = "Reel 9:16") },
                    label = { Text("Reel 9:16") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF1A1208),
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_reel_player")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == StudioTab.CHARACTERS,
                    onClick = { viewModel.selectTab(StudioTab.CHARACTERS) },
                    icon = { Icon(Icons.Default.Group, contentDescription = "Personnages") },
                    label = { Text("Personnages") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF1A1208),
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_characters")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == StudioTab.PRODUCTION_GUIDE,
                    onClick = { viewModel.selectTab(StudioTab.PRODUCTION_GUIDE) },
                    icon = { Icon(Icons.Default.Lightbulb, contentDescription = "Guide 0$") },
                    label = { Text("Guide 0$") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF1A1208),
                        selectedTextColor = GoldPrimary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_production_guide")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.activeTab) {
                StudioTab.EPISODES -> {
                    StudioHomeScreen(
                        episodes = filteredEpisodes,
                        totalEpisodesCount = rawEpisodes.size,
                        uiState = uiState,
                        onSelectArc = { arc -> viewModel.setSelectedArc(arc) },
                        onSelectStatus = { status -> viewModel.setSelectedStatus(status) },
                        onSearchChange = { query -> viewModel.setSearchQuery(query) },
                        onPlayReel = { episode -> viewModel.selectEpisodeForReel(episode) },
                        onEditEpisode = { episode -> viewModel.openEpisodeEditor(episode) },
                        onCreateNextEpisode = { viewModel.createNextEpisode() },
                        onGenerateNextBatch = { viewModel.generateNextBatch(10) },
                        onGenerateAllTo150 = { viewModel.generateAllEpisodesTo150() },
                        onToggleFavorite = { episode -> viewModel.toggleFavorite(episode) },
                        onUpdateStatus = { episode, newStatus -> viewModel.updateStatus(episode, newStatus) },
                        onCopyScript = { episode ->
                            viewModel.copyToClipboard(
                                "Script Épisode ${episode.episodeNumber}",
                                formatFullScript(episode)
                            )
                        },
                        onCopyAiPrompt = { episode ->
                            viewModel.copyToClipboard(
                                "Prompt IA Épisode ${episode.episodeNumber}",
                                episode.visualPrompt
                            )
                        },
                        onExportEpisode = { episode ->
                            viewModel.selectEpisodeForReel(episode)
                            viewModel.openExportModal()
                        },
                        onDeleteEpisode = { episode -> viewModel.deleteEpisode(episode) }
                    )
                }

                StudioTab.REEL_PLAYER -> {
                    ReelPlayerScreen(
                        episode = activeReelEpisode,
                        uiState = uiState,
                        onTogglePlayback = { viewModel.toggleReelPlayback() },
                        onSeek = { pos -> viewModel.seekReel(pos) },
                        onToggleLanguage = { mode -> viewModel.setReelLanguageMode(mode) },
                        onToggleFavorite = { episode -> viewModel.toggleFavorite(episode) },
                        onSpeakScene = { text -> viewModel.speakCurrentSceneText(text) },
                        onStopTts = { viewModel.stopTts() },
                        onToggleAutoNarration = { viewModel.toggleAutoNarration() },
                        onToggleTeleprompter = { viewModel.toggleTeleprompter() },
                        onCopyScript = { episode ->
                            viewModel.copyToClipboard(
                                "Script Épisode ${episode.episodeNumber}",
                                formatFullScript(episode)
                            )
                        },
                        onOpenExportModal = { viewModel.openExportModal() },
                        onStartVoiceRecording = {
                            activeReelEpisode?.let { viewModel.startVoiceRecording(it.episodeNumber) }
                        },
                        onStopVoiceRecording = {
                            activeReelEpisode?.let { viewModel.stopVoiceRecording(it.episodeNumber) }
                        },
                        onPlayVoiceRecording = {
                            activeReelEpisode?.let { viewModel.playVoiceRecording(it.episodeNumber) }
                        },
                        onStopVoicePlayback = { viewModel.stopVoicePlayback() },
                        onDeleteVoiceRecording = {
                            activeReelEpisode?.let { viewModel.deleteVoiceRecording(it.episodeNumber) }
                        },
                        onBackToEpisodes = { viewModel.selectTab(StudioTab.EPISODES) },
                        onAttachVideoClip = { episodeId, sceneNumber, uri ->
                            viewModel.attachVideoClipToScene(episodeId, sceneNumber, uri)
                        },
                        onRemoveVideoClip = { episodeId, sceneNumber ->
                            viewModel.removeVideoClipFromScene(episodeId, sceneNumber)
                        },
                        onCopyPrompt = { label, prompt ->
                            viewModel.copyToClipboard(label, prompt)
                        }
                    )
                }

                StudioTab.CHARACTERS -> {
                    CharactersScreen(
                        onCopyPrompt = { label, prompt -> viewModel.copyToClipboard(label, prompt) }
                    )
                }

                StudioTab.PRODUCTION_GUIDE -> {
                    ProductionGuideScreen()
                }
            }

            // Screenplay Editor Dialog
            uiState.editingEpisode?.let { episode ->
                EpisodeEditorDialog(
                    episode = episode,
                    onDismiss = { viewModel.closeEpisodeEditor() },
                    onSave = { updated -> viewModel.saveEditingEpisode(updated) }
                )
            }

            // MP4 Video Exporter Dialog
            if (uiState.showExportModal && activeReelEpisode != null) {
                VideoExportModal(
                    episode = activeReelEpisode,
                    uiState = uiState,
                    onDismiss = { viewModel.closeExportModal() },
                    onStartExport = { includeVoice -> viewModel.exportCurrentEpisodeToMp4(includeVoice) },
                    onShareVideo = { file -> viewModel.shareExportedVideo(file) }
                )
            }
        }
    }
}

fun formatFullScript(episode: EpisodeEntity): String {
    val scenes = SceneModel.parseList(episode.scenesJson)
    val scenesFormatted = scenes.joinToString("\n\n") { scene ->
        """
        [Scène ${scene.sceneNumber} (${scene.timeStartSec}s-${scene.timeEndSec}s) • ${scene.character} | ${scene.cameraMovement}]
        FR : "${scene.dialogueFr}"
        LN : "${scene.dialogueLn}"
        (SFX : ${scene.sfxAudio} • Émotion : ${scene.emotion})
        """.trimIndent()
    }

    return """
    🎬 LE PRIX DE LA FOI — ÉPISODE ${episode.episodeNumber}/150 (KUMBA CAST)
    Titre FR : ${episode.titleFr}
    Titre Lingala : ${episode.titleLn}
    Format : TikTok & Instagram Reels 9:16 (${episode.durationSeconds} secondes)
    Thème spirituel : ${episode.primaryTheme} (Arc ${episode.arcNumber})

    ⚡ ACCROCHE / HOOK (0-3s) :
    FR : "${episode.hookFr}"
    LN : "${episode.hookLn}"

    --- DÉCOUPAGE DES SCÈNES ---
    $scenesFormatted

    📖 VERSET BIBLIQUE FINAL :
    ${episode.bibleVerseRef}
    FR : "${episode.bibleVerseFr}"
    LN : "${episode.bibleVerseLn}"

    ✨ CALL TO ACTION :
    "${episode.ctaFr}"

    🎨 PROMPT IA RÉALISTE (0$) :
    ${episode.visualPrompt}

    ✂️ GUIDE MONTAGE CAPCUT :
    ${episode.montageGuide}

    Hashtags recommandés :
    #LePrixDeLaFoi #KumbaCast #DrameChretien #CinemaAfricain #ChretienTikTok #Kinshasa #TemoignageChretien #FoiEtEpreuve #GospelSeries
    """.trimIndent()
}
