package com.example.video

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class AudioRecordingManager(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    fun getAudioFile(episodeNumber: Int): File {
        val audioDir = File(context.filesDir, "audio_recordings")
        if (!audioDir.exists()) audioDir.mkdirs()
        return File(audioDir, "episode_${episodeNumber}_voice.m4a")
    }

    fun hasRecording(episodeNumber: Int): Boolean {
        val file = getAudioFile(episodeNumber)
        return file.exists() && file.length() > 0
    }

    fun startRecording(episodeNumber: Int): Boolean {
        try {
            stopPlayback()
            val outputFile = getAudioFile(episodeNumber)
            if (outputFile.exists()) outputFile.delete()

            recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }
            _isRecording.value = true
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            _isRecording.value = false
            return false
        }
    }

    fun stopRecording() {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            recorder = null
            _isRecording.value = false
        }
    }

    fun startPlayback(episodeNumber: Int, onComplete: () -> Unit = {}) {
        val file = getAudioFile(episodeNumber)
        if (!file.exists()) return

        stopPlayback()
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setOnCompletionListener {
                    _isPlaying.value = false
                    onComplete()
                }
                start()
            }
            _isPlaying.value = true
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlaying.value = false
        }
    }

    fun stopPlayback() {
        try {
            player?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            player = null
            _isPlaying.value = false
        }
    }

    fun deleteRecording(episodeNumber: Int) {
        stopPlayback()
        val file = getAudioFile(episodeNumber)
        if (file.exists()) file.delete()
    }
}
