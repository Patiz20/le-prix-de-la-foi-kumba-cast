package com.example.video

import com.example.R
import com.example.data.model.SceneModel
import kotlin.math.cos
import kotlin.math.sin

data class TimedScene(
    val scene: SceneModel,
    val startSec: Float,
    val endSec: Float,
    val durationSec: Float,
    val requiredSpeechSec: Float
)

data class DynamicEpisodeTimeline(
    val timedScenes: List<TimedScene>,
    val climaxStartSec: Float,
    val totalDurationSec: Float,
    val climaxDurationSec: Float
)

data class CinematicParticle(
    val xFraction: Float,
    val yFraction: Float,
    val radiusPx: Float,
    val alpha: Float
)

data class SceneResolution(
    val scene: SceneModel?,
    val isClimax: Boolean,
    val sceneProgress: Float,
    val transitionAlpha: Float,
    val currentDrawableResId: Int,
    val previousDrawableResId: Int = currentDrawableResId,
    val crossFadeProgress: Float = 1.0f,
    val characterDisplay: String,
    val cameraCue: String,
    val sfxCue: String,
    val subtitleFr: String,
    val subtitleLn: String,
    val speechSafeDurationSec: Float = 6.0f
) {
    // Legacy compatibility getter
    val drawableResId: Int get() = currentDrawableResId
}

data class CameraMotion(
    val scale: Float,
    val translationXFraction: Float,
    val translationYFraction: Float,
    val rotationDeg: Float = 0f,
    val shakeXPx: Float = 0f,
    val shakeYPx: Float = 0f,
    val transitionAlpha: Float = 1.0f,
    val breathingScale: Float = 1.0f,
    val atmosphericGlowAlpha: Float = 0.15f
)

object SceneCinematics {

    /**
     * Computes an intelligent, non-cutting dynamic timeline based on actual speech needs.
     * Prevents the narration or dialogue from being truncated before the scene transitions.
     */
    fun computeDynamicTimeline(
        scenes: List<SceneModel>,
        baseDuration: Float = 60f,
        climaxVerse: String = "",
        climaxCta: String = ""
    ): DynamicEpisodeTimeline {
        if (scenes.isEmpty()) {
            val total = baseDuration.coerceIn(45f, 90f)
            return DynamicEpisodeTimeline(
                timedScenes = emptyList(),
                climaxStartSec = 0f,
                totalDurationSec = total,
                climaxDurationSec = total
            )
        }

        val timedList = mutableListOf<TimedScene>()
        var accumulatedTime = 0f

        for (scene in scenes) {
            // Count French dialogue words for speech timing
            val words = scene.dialogueFr.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.size
            // Natural speech rate in French is ~2.3 words/sec + 1.2s of dramatic breathing room
            val speechNeed = if (words > 0) {
                (words / 2.3f) + 1.2f
            } else {
                3.5f
            }

            val nominalDuration = (scene.timeEndSec - scene.timeStartSec).toFloat().coerceAtLeast(4f)
            // Effective scene duration guarantees that speech completes BEFORE the shot changes
            val effectiveDuration = maxOf(nominalDuration, speechNeed).coerceIn(4.5f, 25f)

            val start = accumulatedTime
            val end = accumulatedTime + effectiveDuration

            timedList.add(
                TimedScene(
                    scene = scene,
                    startSec = start,
                    endSec = end,
                    durationSec = effectiveDuration,
                    requiredSpeechSec = speechNeed
                )
            )
            accumulatedTime = end
        }

        // Calculate climax verse speech requirement
        val climaxWords = (climaxVerse + " " + climaxCta).split(Regex("\\s+")).filter { it.isNotBlank() }.size
        val climaxNeed = if (climaxWords > 0) (climaxWords / 2.2f) + 2.5f else 8.0f
        val climaxDuration = climaxNeed.coerceIn(8.5f, 15f)

        val climaxStart = accumulatedTime
        val totalDuration = (climaxStart + climaxDuration).coerceIn(45f, 90f)

        return DynamicEpisodeTimeline(
            timedScenes = timedList,
            climaxStartSec = climaxStart,
            totalDurationSec = totalDuration,
            climaxDurationSec = climaxDuration
        )
    }

    /**
     * Resolves the active scene, seamless cross-fade interpolation, and continuous timeline.
     */
    fun resolveTimeline(
        scenes: List<SceneModel>,
        totalDuration: Float,
        currentTime: Float
    ): SceneResolution {
        val timeline = computeDynamicTimeline(scenes, totalDuration)
        val duration = maxOf(totalDuration, timeline.totalDurationSec).coerceAtLeast(30f)
        val clampedTime = currentTime.coerceIn(0f, duration)

        val climaxStartTime = timeline.climaxStartSec.coerceAtLeast(duration - timeline.climaxDurationSec)
        val isClimax = clampedTime >= climaxStartTime || timeline.timedScenes.isEmpty()

        if (isClimax || timeline.timedScenes.isEmpty()) {
            val climaxSpan = (duration - climaxStartTime).coerceAtLeast(1.0f)
            val progress = ((clampedTime - climaxStartTime) / climaxSpan).coerceIn(0f, 1f)
            val transAlpha = if (progress < 0.15f) (progress / 0.15f).coerceIn(0.4f, 1f) else 1f

            val lastSceneDrawable = timeline.timedScenes.lastOrNull()?.let { resolveSceneDrawable(it.scene) }
                ?: R.drawable.img_reel_dilemma

            return SceneResolution(
                scene = scenes.lastOrNull(),
                isClimax = true,
                sceneProgress = progress,
                transitionAlpha = transAlpha,
                currentDrawableResId = R.drawable.scene_climax_bible,
                previousDrawableResId = lastSceneDrawable,
                crossFadeProgress = (progress / 0.15f).coerceIn(0f, 1f),
                characterDisplay = "KUMBA CAST • Message de Foi",
                cameraCue = "Lueur Divine • Verset Biblique",
                sfxCue = "Chant de Louange Céleste",
                subtitleFr = "",
                subtitleLn = "",
                speechSafeDurationSec = timeline.climaxDurationSec
            )
        }

        // Locate active timed scene
        var activeIndex = -1
        for (i in timeline.timedScenes.indices) {
            val ts = timeline.timedScenes[i]
            if (clampedTime >= ts.startSec && clampedTime < ts.endSec) {
                activeIndex = i
                break
            }
        }

        if (activeIndex == -1) {
            activeIndex = if (clampedTime < (timeline.timedScenes.firstOrNull()?.startSec ?: 0f)) {
                0
            } else {
                timeline.timedScenes.lastIndex
            }
        }

        val timedScene = timeline.timedScenes[activeIndex]
        val scene = timedScene.scene
        val sceneSpan = timedScene.durationSec.coerceAtLeast(1.0f)
        val sceneProgress = ((clampedTime - timedScene.startSec) / sceneSpan).coerceIn(0f, 1f)

        // Smooth cross-fade transition during the first 0.45s of the shot
        val crossFadeDurationSec = 0.45f
        val crossFadeProgress = ((clampedTime - timedScene.startSec) / crossFadeDurationSec).coerceIn(0f, 1f)

        val currentDrawable = resolveSceneDrawable(scene)
        val previousDrawable = if (activeIndex > 0) {
            resolveSceneDrawable(timeline.timedScenes[activeIndex - 1].scene)
        } else {
            currentDrawable
        }

        val transitionAlpha = if (sceneProgress < 0.08f) {
            (sceneProgress / 0.08f).coerceIn(0.35f, 1.0f)
        } else {
            1.0f
        }

        return SceneResolution(
            scene = scene,
            isClimax = false,
            sceneProgress = sceneProgress,
            transitionAlpha = transitionAlpha,
            currentDrawableResId = currentDrawable,
            previousDrawableResId = previousDrawable,
            crossFadeProgress = crossFadeProgress,
            characterDisplay = scene.character,
            cameraCue = "${scene.cameraShot} • ${scene.cameraMovement}",
            sfxCue = scene.sfxAudio,
            subtitleFr = scene.dialogueFr,
            subtitleLn = scene.dialogueLn,
            speechSafeDurationSec = timedScene.requiredSpeechSec
        )
    }

    /**
     * Accurately selects photorealistic character or environmental visuals
     * strictly based on character, setting, action description, and camera shot.
     */
    fun resolveSceneDrawable(scene: SceneModel?): Int {
        if (scene == null) return R.drawable.img_reel_dilemma

        val char = scene.character.lowercase()
        val desc = scene.actionDescription.lowercase()
        val shot = scene.cameraShot.lowercase()
        val emotion = scene.emotion.lowercase()

        // 1. Doctor Kasongo / Physician / Medical Consultation (Dedicated Hospital Doctor Visual)
        if (char.contains("médecin") || char.contains("medecin") || char.contains("docteur") ||
            char.contains("kasongo") || char.contains("monganga") ||
            (desc.contains("médecin") && !char.contains("marie")) || desc.contains("stéthoscope")
        ) {
            return R.drawable.scene_doctor_kasongo
        }

        // 2. Maman Marie (Ailing Mother in Clinic Bed)
        if (char.contains("marie") || char.contains("maman") ||
            desc.contains("lit d'hôpital") || desc.contains("perfusion") || desc.contains("sur son lit")
        ) {
            return R.drawable.scene_marie_hospital
        }

        // 3. Directeur Patrick Bokolo (Corrupt Director / Office / Briefcase / Contracts)
        if (char.contains("bokolo") || char.contains("directeur") || char.contains("patron") ||
            char.contains("client") || desc.contains("mallette") || desc.contains("contrat") ||
            desc.contains("bureau")
        ) {
            return R.drawable.scene_bokolo_office
        }

        // 4. Esther (Prayer / Faith / Intercession)
        if (char.contains("esther") || desc.contains("esther") || desc.contains("prière") ||
            desc.contains("losambo") || desc.contains("mains jointes")
        ) {
            return R.drawable.scene_esther_prayer
        }

        // 5. Pasteur Denis (Church / Parish / Preaching / Wisdom)
        if (char.contains("denis") || char.contains("pasteur") || desc.contains("église") ||
            desc.contains("paroisse") || desc.contains("chaire")
        ) {
            return R.drawable.scene_denis_church
        }

        // 6. Junior (Street Youth / Matonge / Taxi / Motorcycle)
        if (char.contains("junior") || char.contains("kader") || desc.contains("rue") ||
            desc.contains("taxi") || desc.contains("kartye") || desc.contains("jeune") || desc.contains("moto")
        ) {
            return R.drawable.scene_junior_street
        }

        // 7. Samuel (Protagonist - Close-up for anguish/distress vs Medium for reflection)
        if (char.contains("samuel")) {
            return if (shot.contains("gros plan") || shot.contains("serré") || shot.contains("visage") ||
                shot.contains("épaule") || emotion.contains("désespoir") || emotion.contains("choc") ||
                emotion.contains("larmes") || emotion.contains("angoisse") || emotion.contains("ferveur") ||
                desc.contains("sueur") || desc.contains("urgence") || desc.contains("accueil")
            ) {
                R.drawable.scene_samuel_close
            } else {
                R.drawable.img_reel_dilemma
            }
        }

        // 8. Narrateur / Climax / Scripture
        if (char.contains("narrateur") || char.contains("kumba") || desc.contains("verset") || desc.contains("bible")) {
            return if (desc.contains("kinshasa") || desc.contains("ville") || shot.contains("large")) {
                R.drawable.img_hero_drama
            } else {
                R.drawable.scene_climax_bible
            }
        }

        if (desc.contains("clinique") || desc.contains("hôpital")) {
            return R.drawable.scene_doctor_kasongo
        }

        if (desc.contains("atelier") || desc.contains("ordinateur") || desc.contains("ville")) {
            return R.drawable.img_hero_drama
        }

        return R.drawable.img_reel_dilemma
    }

    /**
     * User-facing description of the visual currently displayed,
     * ensuring transparency on whether it matches character, setting, and action.
     */
    fun describeVisualMatch(scene: SceneModel?): String {
        if (scene == null) return "Samuel Mbuyi (Dilemme moral)"
        val char = scene.character.lowercase()
        return when {
            char.contains("médecin") || char.contains("medecin") || char.contains("docteur") || char.contains("kasongo") ->
                "Docteur Kasongo (Consultation médicale à l'hôpital)"
            char.contains("marie") || char.contains("maman") ->
                "Maman Marie (Chambre d'hôpital de la clinique)"
            char.contains("bokolo") || char.contains("directeur") || char.contains("patron") ->
                "Directeur Patrick Bokolo (Bureau de direction à Kinshasa)"
            char.contains("esther") ->
                "Esther (Ferveur et prière d'intercession)"
            char.contains("denis") || char.contains("pasteur") ->
                "Pasteur Denis (Chaire de l'église et parole pastorale)"
            char.contains("junior") ->
                "Junior (Rues animées de Kinshasa)"
            char.contains("samuel") ->
                "Samuel Mbuyi (${if (scene.emotion.isNotBlank()) scene.emotion else "Émotion dramatique"})"
            else -> "${scene.character} (${scene.actionDescription.take(35)})"
        }
    }

    /**
     * Computes multi-layer cinematic camera movements:
     * - Organic breathing motion (gentle sine wave breathing)
     * - Cinematic camera translation (Pan, Dolly, Tilt)
     * - Handheld camera rotational sway (Steadicam feel)
     * - Dynamic tension micro-shake for dramatic moments
     */
    fun computeCameraMotion(
        cameraMovement: String,
        cameraShot: String,
        sceneProgress: Float
    ): CameraMotion {
        val p = sceneProgress.coerceIn(0f, 1f)
        val mov = cameraMovement.lowercase()
        val shot = cameraShot.lowercase()

        // 1. Scene entrance cross-fade (first 10% of the shot)
        val transAlpha = if (p < 0.10f) (0.35f + (p / 0.10f) * 0.65f).coerceIn(0.35f, 1.0f) else 1.0f

        // 2. Organic breathing component (subtle life-like chest breathing rhythm ~0.4 Hz)
        val breathing = 1.0f + (0.012f * sin(p * 3.14159f * 2.0f))

        // 3. Subtle Steadicam rotational drift (±0.6 degree max)
        val rotDeg = 0.5f * sin(p * 3.14159f)

        return when {
            // Pan left -> right
            mov.contains("gauche-droite") || mov.contains("panoramique droite") || mov.contains("droite") -> {
                CameraMotion(
                    scale = 1.12f * breathing,
                    translationXFraction = -0.045f + (0.09f * p),
                    translationYFraction = 0.006f * sin(p * 3.1415f),
                    rotationDeg = rotDeg * 0.5f,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.18f
                )
            }

            // Pan right -> left
            mov.contains("droite-gauche") || mov.contains("panoramique gauche") || mov.contains("gauche") -> {
                CameraMotion(
                    scale = 1.12f * breathing,
                    translationXFraction = 0.045f - (0.09f * p),
                    translationYFraction = 0.006f * sin(p * 3.1415f),
                    rotationDeg = -rotDeg * 0.5f,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.18f
                )
            }

            // Zoom out / Reveal
            mov.contains("arrière") || mov.contains("découverte") || mov.contains("dézoom") -> {
                CameraMotion(
                    scale = (1.18f - (0.12f * p)) * breathing,
                    translationXFraction = 0.005f * sin(p * 3.1415f),
                    translationYFraction = 0.02f * p,
                    rotationDeg = rotDeg * 0.3f,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.14f
                )
            }

            // High angle / Tilt down
            mov.contains("plongée") || mov.contains("descendant") -> {
                CameraMotion(
                    scale = 1.10f * breathing,
                    translationXFraction = 0f,
                    translationYFraction = -0.035f + (0.07f * p),
                    rotationDeg = 0f,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.20f
                )
            }

            // Low angle / Tilt up
            mov.contains("contre-plongée") || mov.contains("ascendant") -> {
                CameraMotion(
                    scale = 1.10f * breathing,
                    translationXFraction = 0f,
                    translationYFraction = 0.035f - (0.07f * p),
                    rotationDeg = 0f,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.25f
                )
            }

            // Dramatic shake / tension (handheld reality)
            mov.contains("tremblement") || mov.contains("choc") || mov.contains("angoisse") -> {
                val shakeX = sin(p * 45f) * 4.5f
                val shakeY = cos(p * 38f) * 2.5f
                CameraMotion(
                    scale = (1.08f + (0.05f * p)) * breathing,
                    translationXFraction = 0f,
                    translationYFraction = 0f,
                    rotationDeg = sin(p * 25f) * 0.8f,
                    shakeXPx = shakeX,
                    shakeYPx = shakeY,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.22f
                )
            }

            // Circular / subtle drift
            mov.contains("circulaire") || mov.contains("doux") || mov.contains("lumière") -> {
                CameraMotion(
                    scale = (1.06f + (0.07f * p)) * breathing,
                    translationXFraction = 0.025f * sin(p * 3.1415f),
                    translationYFraction = 0.02f * cos(p * 3.1415f),
                    rotationDeg = rotDeg,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.28f
                )
            }

            // Default: Continuous slow push-in (Travelling avant / Zoom cinéma)
            else -> {
                val baseScale = if (shot.contains("gros plan") || shot.contains("serré")) 1.08f else 1.04f
                CameraMotion(
                    scale = (baseScale + (0.12f * p)) * breathing,
                    translationXFraction = 0.012f * sin(p * 3.1415f),
                    translationYFraction = -0.025f * p,
                    rotationDeg = rotDeg * 0.4f,
                    transitionAlpha = transAlpha,
                    breathingScale = breathing,
                    atmosphericGlowAlpha = 0.16f
                )
            }
        }
    }

    /**
     * Generates floating ambient cinematic particles (sun dust / divine light motes)
     * computed deterministically based on timeline time in seconds.
     */
    fun getAtmosphericParticles(timeSec: Float, particleCount: Int = 18): List<CinematicParticle> {
        val list = ArrayList<CinematicParticle>(particleCount)
        for (i in 0 until particleCount) {
            val seed = i * 137.5f
            val speed = 0.04f + ((i % 5) * 0.015f)
            val yOffset = ((timeSec * speed + (i * 0.07f)) % 1.0f)
            val y = 1.0f - yOffset // float upwards
            val x = ((sin(timeSec * 0.8f + seed) * 0.15f) + ((i * 0.97f) % 1.0f)).coerceIn(0.05f, 0.95f)
            val alpha = (0.25f + 0.35f * sin(timeSec * 2.0f + seed)).coerceIn(0.1f, 0.7f)
            val radius = 2.0f + (i % 3) * 1.5f
            list.add(CinematicParticle(xFraction = x, yFraction = y, radiusPx = radius, alpha = alpha))
        }
        return list
    }
}

/**
 * Formats biblical text and script references for Text-to-Speech engines,
 * converting colons in chapter/verse notations (e.g. "Proverbes 1:10") into
 * natural spoken words ("Proverbes chapitre 1, verset 10") to avoid TTS engines
 * misinterpreting them as clock times ("1 heure 10").
 */
object BibleSpeechFormatter {

    /**
     * Replaces colon-separated chapter and verse references (e.g. "Proverbes 1:10" or "Jean 3:16-17")
     * with natural spoken French ("chapitre 1, verset 10" / "chapitre 3, versets 16 à 17").
     */
    fun formatForSpeech(text: String): String {
        if (text.isBlank()) return text

        // 1. Chapter and verse ranges: e.g. "1:10-15" or "1:10–15"
        val rangeRegex = Regex("""(\b\d+)\s*:\s*(\d+)\s*[-–]\s*(\d+)\b""")
        var result = rangeRegex.replace(text) { match ->
            val chapter = match.groupValues[1]
            val verseStart = match.groupValues[2]
            val verseEnd = match.groupValues[3]
            "chapitre $chapter, versets $verseStart à $verseEnd"
        }

        // 2. Single chapter and verse: e.g. "1:10" -> "chapitre 1, verset 10"
        val singleRegex = Regex("""(\b\d+)\s*:\s*(\d+)\b""")
        result = singleRegex.replace(result) { match ->
            val chapter = match.groupValues[1]
            val verse = match.groupValues[2]
            "chapitre $chapter, verset $verse"
        }

        return result
    }

    /**
     * Builds the complete spoken climax narration, ensuring the written reference remains intact
     * on screen while the spoken version is natural and phonetic.
     */
    fun buildSpokenClimax(
        bibleVerseRef: String,
        bibleVerseFr: String,
        bibleVerseLn: String,
        ctaFr: String,
        isLingalaMode: Boolean
    ): String {
        val spokenRef = formatForSpeech(bibleVerseRef)
        val verseText = if (isLingalaMode && bibleVerseLn.isNotBlank()) bibleVerseLn else bibleVerseFr
        return "Message de foi. $spokenRef. $verseText. $ctaFr"
    }
}
