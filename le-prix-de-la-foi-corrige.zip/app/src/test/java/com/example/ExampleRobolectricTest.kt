package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CharactersBible
import com.example.data.model.ProductionData
import com.example.data.model.SceneModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Le Prix de la Foi", appName)
    }

    @Test
    fun `verify story arcs configuration covers 150 episodes`() {
        val arcs = ProductionData.arcs
        assertEquals(5, arcs.size)
        assertEquals(1, arcs[0].arcNumber)
        assertEquals(5, arcs[4].arcNumber)

        val slot30 = ProductionData.generateEpisodeSlot(30)
        assertEquals(1, slot30.arcNumber)

        val slot50 = ProductionData.generateEpisodeSlot(50)
        assertEquals(2, slot50.arcNumber)

        val slot150 = ProductionData.generateEpisodeSlot(150)
        assertEquals(5, slot150.arcNumber)
    }

    @Test
    fun `verify initial episodes and scene serialization`() {
        val initialEpisodes = ProductionData.getInitialEpisodes()
        assertTrue(initialEpisodes.isNotEmpty())

        val ep1 = initialEpisodes[0]
        assertEquals(1, ep1.episodeNumber)
        assertFalse(ep1.scenes.isEmpty())

        val entity = ep1.toEntity()
        val parsedScenes = SceneModel.parseList(entity.scenesJson)
        assertEquals(ep1.scenes.size, parsedScenes.size)
        assertEquals(ep1.scenes[0].character, parsedScenes[0].character)
        assertEquals(ep1.scenes[0].dialogueFr, parsedScenes[0].dialogueFr)
    }

    @Test
    fun `verify character bible has key protagonists`() {
        val characters = CharactersBible.characters
        assertTrue(characters.any { it.id == "samuel" })
        assertTrue(characters.any { it.id == "esther" })
        assertTrue(characters.any { it.id == "bokolo" })
        assertTrue(characters.any { it.id == "denis" })
    }

    @Test
    fun `verify full script formatting helper`() {
        val ep1 = ProductionData.getInitialEpisodes().first().toEntity()
        val script = formatFullScript(ep1)
        assertTrue(script.contains("LE PRIX DE LA FOI"))
        assertTrue(script.contains("ÉPISODE 1"))
        assertTrue(script.contains("KUMBA CAST"))
        assertTrue(script.contains("#LePrixDeLaFoi"))
    }

    @Test
    fun `verify initial episodes has exactly 10 fully scripted episodes`() {
        val initialEpisodes = ProductionData.getInitialEpisodes()
        assertEquals(10, initialEpisodes.size)

        for (i in 1..10) {
            val ep = initialEpisodes[i - 1]
            assertEquals(i, ep.episodeNumber)
            assertEquals("SCENARIO_PRET", ep.status)
            assertTrue(ep.titleFr.isNotBlank())
            assertTrue(ep.titleLn.isNotBlank())
            assertTrue(ep.hookFr.isNotBlank())
            assertTrue(ep.hookLn.isNotBlank())
            assertTrue(ep.bibleVerseRef.isNotBlank())
            assertTrue(ep.bibleVerseFr.isNotBlank())
            assertTrue(ep.scenes.isNotEmpty())
            assertTrue(ep.visualPrompt.isNotBlank())
            assertTrue(ep.montageGuide.isNotBlank())
        }

        // Check episode 10 specific climax
        val ep10 = initialEpisodes[9]
        assertEquals("Le Pardon Qui Brise les Chaînes", ep10.titleFr)
        assertEquals("Romains 12:21", ep10.bibleVerseRef)
        assertEquals(5, ep10.scenes.size)
    }

    @Test
    fun `verify audio recording manager creates file path`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = com.example.video.AudioRecordingManager(context)
        val file = manager.getAudioFile(1)
        assertNotNull(file)
        assertTrue(file.name.contains("episode_1_voice"))
    }

    @Test
    fun `verify scene cinematics resolves characters and settings correctly`() {
        val scenes = listOf(
            SceneModel(1, 0, 10, "Directeur Patrick Bokolo", "Plan poitrine", "Zoom avant", "Bokolo ouvre la mallette", "Prends ces 5000 dollars", "", "Sourire", ""),
            SceneModel(2, 10, 20, "Esther Nkumu", "Gros plan", "Lumière douce", "Esther prie avec foi", "Garde ta foi Samuel", "", "Ferveur", ""),
            SceneModel(3, 20, 30, "Pasteur Denis", "Plan moyen", "Panoramique", "Le pasteur montre la Bible", "Dieu ouvre une porte", "", "Paix", ""),
            SceneModel(4, 30, 40, "Maman Marie", "Gros plan", "Lumière douce", "Maman Marie sur son lit d'hôpital", "Mon fils Dieu agira", "", "Dignité", ""),
            SceneModel(5, 40, 50, "Junior", "Plan américain", "Panoramique gauche", "Junior dans la rue de Kinshasa", "Samuel viens voir", "", "Agité", "")
        )

        assertEquals(R.drawable.scene_bokolo_office, com.example.video.SceneCinematics.resolveSceneDrawable(scenes[0]))
        assertEquals(R.drawable.scene_esther_prayer, com.example.video.SceneCinematics.resolveSceneDrawable(scenes[1]))
        assertEquals(R.drawable.scene_denis_church, com.example.video.SceneCinematics.resolveSceneDrawable(scenes[2]))
        assertEquals(R.drawable.scene_marie_hospital, com.example.video.SceneCinematics.resolveSceneDrawable(scenes[3]))
        assertEquals(R.drawable.scene_junior_street, com.example.video.SceneCinematics.resolveSceneDrawable(scenes[4]))
    }

    @Test
    fun `verify continuous timeline resolution without gaps`() {
        val scenes = listOf(
            SceneModel(1, 0, 10, "Samuel", "Gros plan", "Zoom avant", "", "Ligne 1", "", "", ""),
            SceneModel(2, 12, 25, "Bokolo", "Plan moyen", "Panoramique", "", "Ligne 2", "", "", ""),
            SceneModel(3, 27, 45, "Esther", "Plan large", "Travelling", "", "Ligne 3", "", "", "")
        )
        val totalDuration = 60f

        // Time 0 -> Scene 1
        val res0 = com.example.video.SceneCinematics.resolveTimeline(scenes, totalDuration, 0f)
        assertEquals(1, res0.scene?.sceneNumber)
        assertFalse(res0.isClimax)

        // Time 5 (middle of Scene 1, duration 0 to 10s) -> Scene 1
        val res5 = com.example.video.SceneCinematics.resolveTimeline(scenes, totalDuration, 5f)
        assertEquals(1, res5.scene?.sceneNumber)

        // Time 15 (middle of Scene 2, chained seamlessly from 10s to 23s) -> Scene 2
        val res15 = com.example.video.SceneCinematics.resolveTimeline(scenes, totalDuration, 15f)
        assertEquals(2, res15.scene?.sceneNumber)

        // Time 55 -> Climax Verse
        val resClimax = com.example.video.SceneCinematics.resolveTimeline(scenes, totalDuration, 55f)
        assertTrue(resClimax.isClimax)
        assertEquals(R.drawable.scene_climax_bible, resClimax.drawableResId)
    }

    @Test
    fun `verify camera motion computes continuous pan and scale`() {
        // Zoom avant progressive scale
        val motionStart = com.example.video.SceneCinematics.computeCameraMotion("Zoom avant lent", "Plan moyen", 0.0f)
        val motionEnd = com.example.video.SceneCinematics.computeCameraMotion("Zoom avant lent", "Plan moyen", 1.0f)
        assertTrue(motionEnd.scale > motionStart.scale)

        // Panoramique horizontal pan
        val panStart = com.example.video.SceneCinematics.computeCameraMotion("Panoramique gauche-droite", "Plan large", 0.0f)
        val panEnd = com.example.video.SceneCinematics.computeCameraMotion("Panoramique gauche-droite", "Plan large", 1.0f)
        assertTrue(panEnd.translationXFraction > panStart.translationXFraction)
    }

    @Test
    fun `verify bible speech formatter converts references without reading colons as hours`() {
        val singleVerse = com.example.video.BibleSpeechFormatter.formatForSpeech("Proverbes 1:10")
        assertEquals("Proverbes chapitre 1, verset 10", singleVerse)
        assertFalse(singleVerse.contains(":"))

        val verseRange = com.example.video.BibleSpeechFormatter.formatForSpeech("Jean 3:16-18")
        assertEquals("Jean chapitre 3, versets 16 à 18", verseRange)
        assertFalse(verseRange.contains(":"))

        val roman = com.example.video.BibleSpeechFormatter.formatForSpeech("Romains 12:21")
        assertEquals("Romains chapitre 12, verset 21", roman)

        val climax = com.example.video.BibleSpeechFormatter.buildSpokenClimax(
            bibleVerseRef = "Proverbes 1:10",
            bibleVerseFr = "Mon fils, si des pécheurs veulent te séduire, ne cède pas.",
            bibleVerseLn = "",
            ctaFr = "Partage si tu choisis l'intégrité.",
            isLingalaMode = false
        )
        assertTrue(climax.contains("Proverbes chapitre 1, verset 10"))
        assertFalse(climax.contains("1:10"))
    }

    @Test
    fun `verify dynamic speech timeline allocates sufficient duration for dialogue`() {
        val longDialogue = "Seigneur, regarde ma mère sur ce lit d'hôpital. Si je ne trouve pas ces 800 dollars avant ce soir, les médecins menacent de la débrancher. Aide-moi à garder la foi et ne permets pas que je cède au péché du compromis."
        val scenes = listOf(
            SceneModel(1, 0, 5, "Samuel", "Gros plan", "Zoom avant", "Samuel pleure", longDialogue, "", "Désespoir", ""),
            SceneModel(2, 5, 10, "Esther", "Plan moyen", "Panoramique", "Esther prie", "Garde la foi mon fiancé", "", "Ferveur", "")
        )

        val timeline = com.example.video.SceneCinematics.computeDynamicTimeline(
            scenes,
            baseDuration = 45f,
            climaxVerse = "Proverbes 3:5-6",
            climaxCta = "Partage ce témoignage"
        )

        // The first scene had a nominal duration of 5s, but has 42 words needing ~18 seconds!
        // Dynamic timeline must have expanded scene 1 duration to avoid cutting off speech!
        assertTrue(timeline.timedScenes.isNotEmpty())
        val timedScene1 = timeline.timedScenes[0]
        assertTrue("Scene 1 duration must be >= required speech need", timedScene1.durationSec >= timedScene1.requiredSpeechSec)
        assertTrue("Scene 1 must have at least 15s for 42 words", timedScene1.durationSec >= 15f)

        // Total duration must be within 45 to 90 seconds
        assertTrue(timeline.totalDurationSec in 45f..90f)
        assertTrue(timeline.climaxDurationSec >= 8.5f)
    }

    @Test
    fun `verify multi-layer camera motion includes breathing and steadicam rotation`() {
        val motionMid = com.example.video.SceneCinematics.computeCameraMotion("Travelling avant", "Plan moyen", 0.5f)
        assertTrue(motionMid.breathingScale in 0.98f..1.03f)
        assertNotNull(motionMid.rotationDeg)
        assertTrue(motionMid.atmosphericGlowAlpha > 0f)

        val motionShake = com.example.video.SceneCinematics.computeCameraMotion("Choc tremblement", "Gros plan", 0.3f)
        assertTrue(motionShake.shakeXPx != 0f || motionShake.shakeYPx != 0f)
    }

    @Test
    fun `verify atmospheric floating particles are deterministically generated`() {
        val particles = com.example.video.SceneCinematics.getAtmosphericParticles(12.5f, 20)
        assertEquals(20, particles.size)
        for (p in particles) {
            assertTrue(p.xFraction in 0f..1f)
            assertTrue(p.yFraction in 0f..1f)
            assertTrue(p.radiusPx > 0f)
            assertTrue(p.alpha in 0f..1f)
        }
    }

    @Test
    fun `verify harmonic AAC audio generator produces non-empty audio file`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val exporter = com.example.video.LocalMp4VideoExporter(context)
        val tempAudio = java.io.File(context.cacheDir, "test_ambient_${System.currentTimeMillis()}.m4a")

        try {
            exporter.generateHarmonicAudioTrack(1, tempAudio)
            assertTrue(tempAudio.exists())
            assertTrue(tempAudio.length() > 0)
        } finally {
            if (tempAudio.exists()) tempAudio.delete()
        }
    }

    @Test
    fun `verify scene model supports videoUri and preserves backward compatibility`() {
        val sceneWithoutVideo = SceneModel(
            sceneNumber = 1,
            timeStartSec = 0,
            timeEndSec = 10,
            character = "Samuel",
            cameraShot = "Gros plan",
            cameraMovement = "Zoom avant",
            actionDescription = "Prière ardente",
            dialogueFr = "Seigneur fortifie-moi",
            dialogueLn = "Nkolo lendisa ngai",
            emotion = "Dévotion",
            sfxAudio = "Nappe cordes"
        )
        assertFalse(sceneWithoutVideo.hasVideoClip())

        // Verify JSON serialization without videoUri
        val json = sceneWithoutVideo.toJson()
        val parsed = SceneModel.fromJson(json)
        assertEquals(sceneWithoutVideo.sceneNumber, parsed.sceneNumber)
        assertFalse(parsed.hasVideoClip())

        // Verify with videoUri
        val sceneWithVideo = sceneWithoutVideo.copy(videoUri = "/data/user/0/app/scene_videos/ep1_sc1.mp4")
        assertTrue(sceneWithVideo.hasVideoClip())
        val jsonWithVideo = sceneWithVideo.toJson()
        val parsedWithVideo = SceneModel.fromJson(jsonWithVideo)
        assertTrue(parsedWithVideo.hasVideoClip())
        assertEquals("/data/user/0/app/scene_videos/ep1_sc1.mp4", parsedWithVideo.videoUri)
    }

    @Test
    fun `verify AI video prompt generator produces tailored 9_16 cinema prompts`() {
        val scene = SceneModel(
            sceneNumber = 1,
            timeStartSec = 0,
            timeEndSec = 12,
            character = "Pasteur Samuel",
            cameraShot = "Gros plan regard",
            cameraMovement = "Travelling avant lent",
            actionDescription = "Samuel regarde le ciel de Kinshasa les larmes aux yeux en tenant sa Bible",
            dialogueFr = "Pardonne-leur car ils ne savent ce qu'ils font",
            dialogueLn = "",
            emotion = "Pardon et ferveur",
            sfxAudio = "Violoncelle solo"
        )

        val prompt = scene.generateAiVideoPrompt(episodeNumber = 1, theme = "Foi et Épreuve")
        assertTrue(prompt.contains("9:16"))
        assertTrue(prompt.contains("Pastor Samuel") || prompt.contains("Samuel"))
        assertTrue(prompt.contains("Kinshasa"))
        assertTrue(prompt.contains("Gros plan regard"))
        assertTrue(prompt.contains("Travelling avant lent"))
        assertTrue(prompt.contains("KUMBA CAST"))
        assertTrue(prompt.contains("Kling AI") || prompt.contains("motion") || prompt.contains("dialogue"))
    }

    @Test
    fun `verify doctor and hospital scenes are accurately distinguished`() {
        val doctorScene = SceneModel(
            sceneNumber = 2,
            timeStartSec = 10,
            timeEndSec = 25,
            character = "Médecin",
            cameraShot = "Plan moyen souriant",
            cameraMovement = "Zoom lent",
            actionDescription = "Le médecin tend une enveloppe tamponnée ACQUITTÉ.",
            dialogueFr = "Calmez-vous jeune homme. Toute l'intervention est payée.",
            dialogueLn = "Kitisa motema elenge.",
            emotion = "Soulagement",
            sfxAudio = "Cordes lumineuses"
        )
        val doctorDrawable = com.example.video.SceneCinematics.resolveSceneDrawable(doctorScene)
        assertEquals(R.drawable.scene_doctor_kasongo, doctorDrawable)

        val motherScene = SceneModel(
            sceneNumber = 3,
            timeStartSec = 26,
            timeEndSec = 45,
            character = "Maman Marie",
            cameraShot = "Gros plan radieux",
            cameraMovement = "Lumière douce",
            actionDescription = "Maman Marie prend le visage de Samuel sur son lit de clinique.",
            dialogueFr = "Je te l'avais dit Samuel... Nzambe azali Nzambe !",
            dialogueLn = "Nayebisaki yo Samuel.",
            emotion = "Gratitude émue",
            sfxAudio = "Hymne gospel"
        )
        val motherDrawable = com.example.video.SceneCinematics.resolveSceneDrawable(motherScene)
        assertEquals(R.drawable.scene_marie_hospital, motherDrawable)

        val visualDesc = com.example.video.SceneCinematics.describeVisualMatch(doctorScene)
        assertTrue(visualDesc.contains("Docteur") || visualDesc.contains("Médecin"))
    }
}

